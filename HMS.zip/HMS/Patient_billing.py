# Developed and designed By Abdul Muhaimin

import tkinter as tk
import uuid
from tkinter import ttk

bill = tk.Toplevel()

bill.title('Accountant / Patient Billing')
global logo
logo = tk.PhotoImage(file="img/account.png")
bill.iconphoto(False, logo)

# MenuBar

# Menu developed by abdul Muhaimin

menubar = tk.Menu(bill)
# Adding File Menu and commands
file = tk.Menu(menubar, tearoff=0)
menubar.add_cascade(label='File', menu=file)

def logout():
    bill.destroy()

    import Login

file.add_command(label='Logout', command=logout)
file.add_separator()
file.add_command(label='Exit', command=bill.destroy)

# Adding Help Menu
patients_ = tk.Menu(menubar, tearoff=0)
menubar.add_cascade(label='Billing', menu=patients_)

patients_.add_command(label='Patient Billing')

def ob():
    import overall_billing

patients_.add_command(label='Overall Billing', command=ob)
patients_.add_separator()

bill.config(menu=menubar)
# Menu developed by abdul Muhaimin

# screen1 centering
screen_width = bill.winfo_screenwidth()
screen_height = bill.winfo_screenheight()

w_width = 1050
w_height = 600

center_x = int(screen_width / 2 - w_width / 2)
center_y = int(screen_height / 2 - w_height / 2)

bill.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')
bill.configure(bg="white")

from db_conn import db

cursor = db.cursor()
cursor.execute('select * from In_patient LIMIT  0,5')
records = cursor.fetchall()

Frame1 = tk.Frame(bill, width=450, height=600, background='white')
Frame1.pack(side=tk.LEFT, padx=55)

Label = ttk.Label(Frame1, text='Patient Treated', font=("Arial Black", 12), background='white')
Label.grid(columnspan=2)

label_1 = ttk.Label(Frame1, text='Patient Id', background='white')
label_1.grid(row=1, column=0, padx=20, pady=30, sticky='w')


entry_1 = ttk.Entry(Frame1, width=15)
entry_1.grid(row=1, column=1, sticky='w')

# Name label and field
label_2 = ttk.Label(Frame1, text='Name', background='white')
label_2.grid(row=2, column=0, padx=20, pady=30, sticky='w')

entry_2 = ttk.Entry(Frame1, width=15, font='Helvetica')
entry_2.grid(row=2, column=1, columnspan=3, sticky='w')

# Contact label and field
label_3 = ttk.Label(Frame1, text='Doctor Fees', background='white')
label_3.grid(row=3, column=0, padx=20, pady=30, sticky='w')

entry_3 = ttk.Entry(Frame1, width=20)
entry_3.grid(row=3, column=1, sticky='w', pady=30)

# Date label and field
label_4 = ttk.Label(Frame1, text='Test Fees', background='white')
label_4.grid(row=4, column=0, padx=20, sticky='w', pady=30)

entry_4 = ttk.Entry(Frame1)
entry_4.grid(row=4, column=1, sticky='w')

label_5 = ttk.Label(Frame1, text='Medicines Fees', background='white')
label_5.grid(row=5, column=0, padx=20, sticky='w', pady=30)

entry_5 = ttk.Entry(Frame1)
entry_5.grid(row=5, column=1, sticky='w')

def save():
    id = entry_1.get()
    name = entry_2.get()
    d_fess = entry_3.get()
    t_fess = entry_4.get()
    m_fees = entry_5.get()

    mycursor = db.cursor()

    sql = "INSERT INTO bills (id, Name, doctor_fess, test_fess, medicines_fess) VALUES (%s, %s, %s, %s, %s)"
    val = (id, name, d_fess, t_fess, m_fees)
    mycursor.execute(sql, val)

    db.commit()
    entry_1.delete(0, tk.END)
    entry_2.delete(0, tk.END)
    entry_3.delete(0, tk.END)
    entry_4.delete(0, tk.END)
    entry_5.delete(0, tk.END)
    print(mycursor.rowcount, "record inserted.")

# Buttons
save = tk.Button(Frame1, text='Save', width=15, border=2, background='#f84477', foreground='white',command=save)
save.grid(row=7, column=1, padx=15, pady=10)

frame2 = tk.Frame(bill)
frame2.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
frame2.configure(bg="white")

# VIew tree 1
frame_Frame2 = tk.Frame(frame2, width=450, height=600, background='white')
frame_Frame2.pack(padx=55, pady=15)


my_tree = ttk.Treeview(frame_Frame2, columns=(1, 2, 3, 4), show='headings', selectmode='browse')
my_tree.pack(side='left')
my_tree.configure(height=4)

my_tree.column(1, width=120, anchor='center')
my_tree.column(2, width=120, anchor='center')
my_tree.column(3, width=120, anchor='center')
my_tree.column(4, width=120, anchor='center')

my_tree.heading(1, text='Id')
my_tree.heading(2, text='name')
my_tree.heading(3, text='gender')
my_tree.heading(4, text='Contact')

for record in records:
    my_tree.insert('', 'end', iid=record[0],
                   values=(record[0], record[1], record[2], record[3], record[4]))

verscrlbar = ttk.Scrollbar(frame_Frame2,
                           orient="vertical",

                           command=my_tree.yview)
my_tree.configure(yscrollcommand=verscrlbar.set, )

verscrlbar.pack(side=tk.LEFT, expand=True, fill="y")

# VIew tree 1

# view tree 2
frame_Frame3 = tk.Frame(frame2, width=450, height=600, background='white')
frame_Frame3.pack(padx=55, pady=15)

my_tree1 = ttk.Treeview(frame_Frame3, columns=(1, 2, 3, 4), show='headings', selectmode='browse')
my_tree1.pack(side='left')
my_tree1.configure(height=4)

my_tree1.column(1, width=120, anchor='center')
my_tree1.column(2, width=120, anchor='center')
my_tree1.column(3, width=120, anchor='center')
my_tree1.column(4, width=120, anchor='center')

my_tree1.heading(1, text='Id')
my_tree1.heading(2, text='name')
my_tree1.heading(3, text='gender')
my_tree1.heading(4, text='Contact')

cursor = db.cursor()
cursor.execute('select * from Out_patient LIMIT  0,5')
outs = cursor.fetchall()

for out in outs:
    my_tree1.insert('', 'end', iid=out[0],
                    values=(out[0], out[1], out[2], out[3], out[4]))

verscrlbar1 = ttk.Scrollbar(frame_Frame3,
                            orient="vertical",

                            command=my_tree1.yview)
my_tree1.configure(yscrollcommand=verscrlbar1.set, )

verscrlbar1.pack(side=tk.LEFT, expand=True, fill="y")

# view tree 2


# view tree 3
frame_Frame4 = tk.Frame(frame2, width=450, height=600, background='white')
frame_Frame4.pack(padx=55, pady=15)

my_tree2 = ttk.Treeview(frame_Frame4, columns=(1, 2, 3, 4), show='headings', selectmode='browse')
my_tree2.pack(side='left')

my_tree2.column(1, width=120, anchor='center')
my_tree2.column(2, width=120, anchor='center')
my_tree2.column(3, width=120, anchor='center')
my_tree2.column(4, width=120, anchor='center')

my_tree2.heading(1, text='Id')
my_tree2.heading(2, text='name')
my_tree2.heading(3, text='Emergency')
my_tree2.heading(4, text='D_assigned')
my_tree2.configure(height=4)
cursor = db.cursor()
cursor.execute('select * from EM_patient LIMIT  0,5')
EMS = cursor.fetchall()

for EM in EMS:
    my_tree2.insert('', 'end', iid=EM[0],
                    values=(EM[0], EM[1], EM[2], EM[3]))

style = ttk.Style()
style.theme_use("clam")



verscrlbar2 = ttk.Scrollbar(frame_Frame4,
                            orient="vertical",

                            command=my_tree2.yview)
my_tree2.configure(yscrollcommand=verscrlbar2.set, )

verscrlbar2.pack(side=tk.LEFT, expand=True, fill="y")

# view tree 3

# view tree 4
frame_Frame5 = tk.Frame(frame2, width=450, height=600, background='white')
frame_Frame5.pack(padx=55, pady=15)

my_tree3 = ttk.Treeview(frame_Frame5, columns=(1, 2, 3, 4), show='headings', selectmode='browse')
my_tree3.pack(side='left')

my_tree3.column(1, width=120, anchor='center')
my_tree3.column(2, width=120, anchor='center')
my_tree3.column(3, width=120, anchor='center')
my_tree3.column(4, width=120, anchor='center')

# mycursor.execute('create table admitted (id varchar (200), Name varchar (200), admit_days int)')
my_tree3.heading(1, text='id')
my_tree3.heading(2, text='name')
my_tree3.heading(3, text='admit_days')
my_tree3.configure(height=4)
cursor = db.cursor()
cursor.execute('select * from admitted  LIMIT  0,3')
adm = cursor.fetchall()

for ad in adm:
    my_tree3.insert('', 'end', iid=ad[0],
                    values=(ad[0], ad[1], ad[2]))

style = ttk.Style()
style.theme_use("clam")



verscrlbar3 = ttk.Scrollbar(frame_Frame5,
                            orient="vertical",

                            command=my_tree3.yview)
my_tree3.configure(yscrollcommand=verscrlbar3.set, )

verscrlbar3.pack(side=tk.LEFT, expand=True, fill="y")

# view tree 4
bill.mainloop()
