# Made by Abdul Muhaimin
import tkinter as tk
from tkinter import ttk
import employee_modules as em

global screen
screen = tk.Toplevel()
screen.configure(background='white')

# title&icon
screen.title('Employee')
image = tk.PhotoImage(file='img/employee.png')
screen.iconphoto(True, image)
screen.iconname('employee')

# screen centering
screen_width = screen.winfo_screenwidth()
screen_height = screen.winfo_screenheight()
w_width = 900
w_height = 600
center_x = int(screen_width / 2 - w_width / 2)
center_y = int(screen_height / 2 - w_height / 2)
screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')
from db_conn import db

cursor = db.cursor()


img = tk.PhotoImage(file='img/Staff.png')
label1 = ttk.Label(screen, image=img, background="white")
label1.image = img
label1.pack()

screen_label = ttk.Label(screen, text='Hello! View Your Profile', font=('Cooper Black', 22),
                         foreground='#f84477',
                         background='white')
screen_label.pack()

label1 = tk.Label(screen, text='Unique ID', background='white', font=('Times', 12, 'bold'))
label1.pack()

entry1 = ttk.Entry(screen, background='white')
entry1.pack()


def profile():
    cursor.execute(f"SELECT * FROM employee where ID = '{entry1.get()}'")
    records = cursor.fetchall()



    for record in records:
        screen = tk.Toplevel()
        screen.configure(background='white')
        screen.title('Profile')

        global image
        image = tk.PhotoImage(file='img/Staff.png')
        screen.iconphoto(False, image)

        label_i = tk.Label(screen, image=image, background='white')
        label_i.grid(row=0, column=5, columnspan=2, rowspan=7, padx=10, pady=40)

        screen_width = screen.winfo_screenwidth()
        screen_height = screen.winfo_screenheight()
        w_width = 900
        w_height = 600
        center_x = int(screen_width / 2 - w_width / 2)
        center_y = int(screen_height / 2 - w_height / 2)
        screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

        sno = record[0]
        uid = record[1]
        name = record[2]
        age = record[3]
        department = record[4]
        salary = record[5]
        qualification = record[6]

        label0 = tk.Label(screen, text='Serial No: ' + str(sno) + '\n', background='white',
                          font=('Times', 13, 'bold'))
        label0.grid(row=0, column=0, padx=30, pady=20, sticky='w')

        label1 = tk.Label(screen, text='Unique Id: ' + str(uid) + '\n', background='white',
                          font=('Times', 13, 'bold'))
        label1.grid(row=1, column=0, padx=30, pady=20, sticky='w')

        label2 = tk.Label(screen, text='Name: ' + name + '\n', background='white', font=('Times', 13, 'bold'))
        label2.grid(row=2, column=0, padx=30, pady=20, sticky='w')

        label3 = tk.Label(screen, text='Age: ' + str(age) + '\n', background='white', font=('Times', 13, 'bold'))
        label3.grid(row=3, column=0, padx=30, pady=20, sticky='w')

        label4 = tk.Label(screen, text='Department: ' + department + '\n', background='white',
                          font=('Times', 13, 'bold'))
        label4.grid(row=4, column=0, padx=30, pady=20, sticky='w')

        label5 = tk.Label(screen, text='Salary: ' + str(salary) + ' Rs \n', background='white',
                          font=('Times', 13, 'bold'))
        label5.grid(row=5, column=0, padx=30, pady=20, sticky='w')

        label6 = tk.Label(screen, text='Qualification: ' + qualification + '\n', background='white',
                          font=('Times', 13, 'bold'))
        label6.grid(row=6, column=0, padx=30, pady=20, sticky='w')




def recent_payroll():
    import tkinter as tk
    from tkinter import ttk

    # record(ID, Name, Age, type , date varchar,result,remarks
    cursor.execute(f'SELECT * FROM payroll ORDER BY Sno DESC LIMIT 1; where uid = "{entry1.get()} "')
    records = cursor.fetchall()

    count = 0
    for record in records:
        if count < 1:
            sno = record[0]
            uid = record[1]
            name = record[2]
            age = record[3]
            department = record[4]
            salary = record[5]
            qualification = record[6]
            loans = record[7]
            other_charges = record[8]
            tax = record[9]
            net_pay = record[10]

            screen = tk.Toplevel()
            screen.configure(background='white')
            screen.title('Recent Payroll')
            image = tk.PhotoImage(file='img/report.png')
            screen.iconphoto(True, image)
            screen.iconname('pathology')
            screen.configure(background='white')
            image1 = tk.PhotoImage(file='img/report.png')

            label = ttk.Label(screen, image=image1, background='white')
            label.grid(row=1, column=2, rowspan=4, padx=40, pady=10)

            screen_width = screen.winfo_screenwidth()
            screen_height = screen.winfo_screenheight()
            w_width = 900
            w_height = 600
            center_x = int(screen_width / 2 - w_width / 2)
            center_y = int(screen_height / 2 - w_height / 2)
            screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

            label1 = tk.Label(screen, text='Unique Id: ' + str(uid) + '\n', background='white',
                              font=('Times', 13, 'bold'))
            label1.grid(row=0, column=0, padx=30, pady=20, sticky='w')

            label2 = tk.Label(screen, text='Name: ' + name + '\n', background='white', font=('Times', 13, 'bold'))
            label2.grid(row=1, column=0, padx=30, pady=20, sticky='w')

            label3 = tk.Label(screen, text='Age: ' + str(age) + '\n', background='white', font=('Times', 13, 'bold'))
            label3.grid(row=2, column=0, padx=30, pady=20, sticky='w')

            label4 = tk.Label(screen, text='department: ' + department + '\n', background='white',
                              font=('Times', 13, 'bold'))
            label4.grid(row=3, column=0, padx=30, pady=20, sticky='w')

            label5 = tk.Label(screen, text='salary: ' + f"{salary}" + '\n', background='white', font=('Times', 13, 'bold'))
            label5.grid(row=4, column=0, padx=30, pady=20, sticky='w')

            label6 = tk.Label(screen, text='qualification: ' + qualification + '\n', background='white', font=('Times', 13, 'bold'))
            label6.grid(row=5, column=0, padx=30, pady=20, sticky='w')

            label7 = tk.Label(screen, text='loans: ' + f"{loans}" + '\n', background='white', font=('Times', 13, 'bold'))
            label7.grid(row=0, column=5, padx=30, pady=20, sticky='w')

            label8 = tk.Label(screen, text='other_charges: ' + f"{other_charges}" + '\n', background='white', font=('Times', 13, 'bold'))
            label8.grid(row=1, column=5, padx=30, pady=20, sticky='w')

            label9 = tk.Label(screen, text='tax: ' + f"{tax}" + '\n', background='white', font=('Times', 13, 'bold'))
            label9.grid(row=2, column=5, padx=30, pady=20, sticky='w')

            label10 = tk.Label(screen, text='Net_pay ' + f"{net_pay}" + '\n', background='white', font=('Times', 13, 'bold'))
            label10.grid(row=3, column=5, padx=30, pady=20, sticky='w')

            count += 1

            screen.mainloop()




def logout():
    screen.destroy()
    import Login

btn2 = tk.Button(screen, text="Log - out", command=logout, bg="#f84477", pady=5, padx=5, fg="white").pack(pady=15)

btn = tk.Button(screen, text="Check profile", command=profile, bg="#f84477", pady=5, padx=5, fg="white").pack(pady=15)
btn1 = tk.Button(screen, text="Check Payroll", command=recent_payroll, bg="#f84477", pady=5, padx=5, fg="white").pack(pady=15)



screen.mainloop()
