# developer= <---------Nazzal Kausar---------->

import mysql.connector
from db_conn import db


# cursor.execute('create table record(Sno int key Auto_increment, ID varchar (200),Name varchar (200),Age int, type varchar (200) , date varchar (100),result varchar (200),remarks varchar(250))')


def add_record():
    from db_conn import db
    cursor = db.cursor()

    import tkinter as tk
    from tkinter import ttk
    import uuid
    from datetime import date
    screen = tk.Toplevel()
    screen.configure(background='white')
    screen.title('Add Record')

    global image
    image = tk.PhotoImage(file='img/report.png')
    screen.iconphoto(False, image)



    label_i = tk.Label(screen, image=image, background='white', )
    label_i.grid(row=0, column=5, columnspan=2, rowspan=8, padx=10, pady=40)

    def menu():
        # Menu developed by abdul Muhaimin

        menubar = tk.Menu(screen)
        # Adding File Menu and commands
        file = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label='File', menu=file)

        def logout():
            screen.destroy()

            import Login

        file.add_command(label='Logout', command=logout)
        file.add_separator()
        file.add_command(label='Exit', command=screen.destroy)

        # Adding Help Menu
        patients_ = tk.Menu(menubar, tearoff=0)

        menubar.add_cascade(label='Records', menu=patients_)


        patients_.add_command(label='Add Record', command=add_record)

        patients_.add_command(label='Recent Test', command=recent_tests)
        patients_.add_separator()

        patients_.add_command(label='Search Record', command=search_record)
        patients_.add_command(label='remove Record', command=remove_record)
        screen.config(menu=menubar)
        # Menu developed by abdul Muhaimin

    menu()
    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()
    w_width = 900
    w_height = 600
    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)
    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

    label0 = ttk.Label(screen, text='  ', background='white', foreground='#f84477', font=('Cooper Black', 20))
    label0.grid(row=0, column=4, columnspan=2, padx=20, sticky='s')

    # Id label And Entry

    label1 = tk.Label(screen, text='Patient ID', background='white', font=('Times', 12, 'bold'))
    label1.grid(row=1, column=0, padx=30, pady=20, sticky='w')

    entry1 = ttk.Entry(screen, background='white')
    entry1.grid(row=1, column=1, padx=30, pady=20, ipadx=15, sticky='w')
    uid = uuid.uuid1()
    x = str(uid)[:4]
    entry1.insert(0, x)
    entry1.configure(state='disabled')

    # Name label and entry

    label2 = tk.Label(screen, text='Name', background='white', font=('Times', 12, 'bold'))
    label2.grid(row=2, column=0, padx=30, pady=20, sticky='w')

    entry2 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry2.grid(row=2, column=1, padx=30, pady=20, ipadx=15, sticky='w')

    # Age label and entry
    label3 = tk.Label(screen, text='Age', background='white', font=('Times', 12, 'bold'))
    label3.grid(row=3, column=0, padx=30, pady=20, sticky='w')

    entry3 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry3.grid(row=3, column=1, padx=30, pady=20, ipadx=15, sticky='w')

    # Test Type label and entry
    label4 = tk.Label(screen, text='Test Type', background='white', font=('Times', 12, 'bold'))
    label4.grid(row=4, column=0, padx=30, pady=20, sticky='w')

    entry4 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry4.grid(row=4, column=1, padx=30, pady=20, ipadx=15, sticky='w')

    # Result label and entry
    label5 = tk.Label(screen, text='Result', background='white', font=('Times', 12, 'bold'))
    label5.grid(row=5, column=0, padx=30, pady=20, sticky='w')

    entry5 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry5.grid(row=5, column=1, padx=30, pady=20, ipadx=15, sticky='w')

    # Date label and entry
    label6 = tk.Label(screen, text='Date', background='white', font=('Times', 12, 'bold'))
    label6.grid(row=6, column=0, padx=30, pady=20, sticky='w')

    entry6 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry6.grid(row=6, column=1, padx=30, pady=20, ipadx=15, sticky='w')
    entry6.insert(0, str(date.today()))
    entry6.configure(state='disabled')

    # Remarks widget and label
    label6 = tk.Label(screen, text='Remarks', background='white', font=('Times', 12, 'bold'))
    label6.grid(row=7, column=0, padx=30, pady=20, sticky='w')

    widg1 = tk.Text(screen, height=4, width=15, background='white', font=('Times', 12))
    widg1.grid(row=7, column=1, padx=30, pady=20, ipadx=15, sticky='w')

    # blank label
    label7 = tk.Label(screen, text='                ', background='white')
    label7.grid(row=0, column=3, rowspan=6, padx=20, ipadx=30)

    def add():
        data = (
        entry1.get(), entry2.get(), entry3.get(), entry4.get(), entry5.get(), entry6.get(), widg1.get("1.0", 'end'))
        entry1.delete(0, 'end')
        entry2.delete(0, 'end')
        entry3.delete(0, 'end')
        entry4.delete(0, 'end')
        entry5.delete(0, 'end')
        entry6.delete(0, 'end')
        widg1.delete("1.0", 'end')

        query = ('insert into record(ID, Name, Age, type , date,result,remarks) Values(%s,%s,%s,%s,%s,%s,%s)')

        cursor.execute(query, data)
        db.commit()
        screen.quit()

    # Buttons
    button1 = tk.Button(screen, text='Add Record', width=10, background='#f84477', foreground='white',
                        font=('Times', 11, 'bold'), command=add)
    button1.grid(row=8, column=1, padx=20, pady=10)

    screen.mainloop()


def remove_record():
    from db_conn import db
    cursor = db.cursor()

    import tkinter as tk
    from tkinter import ttk

    screen = tk.Toplevel()
    screen.configure(background='white')
    screen.title('Remove Record')

    global image
    image = tk.PhotoImage(file='img/report.png')
    screen.iconphoto(False, image)

    def menu():
        # Menu developed by abdul Muhaimin

        menubar = tk.Menu(screen)
        # Adding File Menu and commands
        file = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label='File', menu=file)

        def logout():
            screen.destroy()

            import Login

        file.add_command(label='Logout', command=logout)
        file.add_separator()
        file.add_command(label='Exit', command=screen.destroy)

        # Adding Help Menu
        patients_ = tk.Menu(menubar, tearoff=0)

        menubar.add_cascade(label='Records', menu=patients_)


        patients_.add_command(label='Add Record', command=add_record)

        patients_.add_command(label='Recent Test', command=recent_tests)
        patients_.add_separator()

        patients_.add_command(label='Search Record', command=search_record)
        patients_.add_command(label='remove Record', command=remove_record)
        screen.config(menu=menubar)
        # Menu developed by abdul Muhaimin

    menu()

    label_i = tk.Label(screen, image=image, background='white')
    label_i.grid(row=0, column=5, columnspan=2, rowspan=8, padx=10, pady=40)

    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()
    w_width = 900
    w_height = 600
    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)
    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

    label0 = ttk.Label(screen, text='  ', background='white', foreground='#f84477', font=('Cooper Black', 20))
    label0.grid(row=0, column=4, columnspan=2, padx=20, sticky='s')

    # Id label And Entry

    label1 = tk.Label(screen, text='Patient ID', background='white', font=('Times', 12, 'bold'))
    label1.grid(row=1, column=0, padx=30, pady=20, sticky='w')

    entry1 = ttk.Entry(screen, background='white')
    entry1.grid(row=1, column=1, padx=30, pady=20, ipadx=15, sticky='w')

    # Name label and entry

    label2 = tk.Label(screen, text='Name', background='white', font=('Times', 12, 'bold'))
    label2.grid(row=2, column=0, padx=30, pady=20, sticky='w')

    entry2 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry2.grid(row=2, column=1, padx=30, pady=20, ipadx=15, sticky='w')

    # Test Type label and entry
    label3 = tk.Label(screen, text='Test Type', background='white', font=('Times', 12, 'bold'))
    label3.grid(row=3, column=0, padx=30, pady=20, sticky='w')

    entry3 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry3.grid(row=3, column=1, padx=30, pady=20, ipadx=15, sticky='w')

    # Date label and entry
    label4 = tk.Label(screen, text='Date', background='white', font=('Times', 12, 'bold'))
    label4.grid(row=4, column=0, padx=30, pady=20, sticky='w')

    entry4 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry4.grid(row=4, column=1, padx=30, pady=20, ipadx=15, sticky='w')
    entry4.insert(0, 'YY-MM-DD')

    # blank label
    label5 = tk.Label(screen, text='                ', background='white')
    label5.grid(row=0, column=3, rowspan=6, padx=20, ipadx=30)

    def remove_button():
        cursor.execute(f"DELETE FROM record where ID = '{entry1.get()}'")
        db.commit()
        entry1.delete(0, 'end')
        entry2.delete(0, 'end')
        entry3.delete(0, 'end')
        entry4.delete(0, 'end')

    # Buttons
    button1 = tk.Button(screen, text='Remove', width=10, background='#f84477', foreground='white',
                        font=('Times', 11, 'bold'), command=remove_button)
    button1.grid(row=5, column=1, padx=20, pady=10)

    screen.mainloop()


def search_record():
    from db_conn import db
    cursor = db.cursor()

    import tkinter as tk
    from tkinter import ttk
    screen = tk.Toplevel()
    screen.configure(background='white')
    screen.title('Search Record')

    global image
    image = tk.PhotoImage(file='img/report.png')
    screen.iconphoto(False, image)

    label_i = tk.Label(screen, image=image, background='white')
    label_i.grid(row=0, column=5, columnspan=2, rowspan=8, padx=10, pady=40)

    def menu():
        # Menu developed by abdul Muhaimin

        menubar = tk.Menu(screen)
        # Adding File Menu and commands
        file = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label='File', menu=file)

        def logout():
            screen.destroy()

            import Login

        file.add_command(label='Logout', command=logout)
        file.add_separator()
        file.add_command(label='Exit', command=screen.destroy)

        # Adding Help Menu
        patients_ = tk.Menu(menubar, tearoff=0)

        menubar.add_cascade(label='Records', menu=patients_)


        patients_.add_command(label='Add Record', command=add_record)

        patients_.add_command(label='Recent Test', command=recent_tests)
        patients_.add_separator()

        patients_.add_command(label='Search Record', command=search_record)
        patients_.add_command(label='remove Record', command=remove_record)
        screen.config(menu=menubar)
        # Menu developed by abdul Muhaimin

    menu()

    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()
    w_width = 900
    w_height = 600
    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)
    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

    label0 = ttk.Label(screen, text='  ', background='white', foreground='#f84477', font=('Cooper Black', 20))
    label0.grid(row=0, column=4, columnspan=2, padx=20, sticky='s')

    # #Id label And Entry

    # label1=tk.Label(screen,text='Patient ID',background='white',font=('Times',12,'bold'))
    # label1.grid(row=1,column=0,padx=30,pady=20,sticky='w')

    entry1 = ttk.Entry(screen, background='white')
    entry1.grid(row=1, column=1, padx=30, pady=20, ipadx=15, sticky='w')
    entry1.insert(0, 'Enter unique ID')

    # Name label and entry

    label2 = tk.Label(screen, text='Name', background='white', font=('Times', 12, 'bold'))
    label2.grid(row=2, column=0, padx=30, pady=20, sticky='w')

    entry2 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry2.grid(row=2, column=1, padx=30, pady=20, ipadx=15, sticky='w')

    # Test Type label and entry
    label3 = tk.Label(screen, text='Test Type', background='white', font=('Times', 12, 'bold'))
    label3.grid(row=3, column=0, padx=30, pady=20, sticky='w')

    entry3 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry3.grid(row=3, column=1, padx=30, pady=20, ipadx=15, sticky='w')

    # Date label and entry
    label4 = tk.Label(screen, text='Date', background='white', font=('Times', 12, 'bold'))
    label4.grid(row=4, column=0, padx=30, pady=20, sticky='w')

    entry4 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry4.grid(row=4, column=1, padx=30, pady=20, ipadx=15, sticky='w')
    entry4.insert(0, 'YY-MM-DD')

    # blank label
    label5 = tk.Label(screen, text='                ', background='white')
    label5.grid(row=0, column=3, rowspan=6, padx=20, ipadx=30)

    def search_button():
        cursor.execute(f"SELECT * FROM record where ID = '{entry1.get()}'")
        records = cursor.fetchall()
        for record in records:
            screen = tk.Toplevel()
            screen.configure(background='white')
            screen.title('Search Record')

            global image
            image = tk.PhotoImage(file='img/report.png')
            screen.iconphoto(False, image)

            label_i = tk.Label(screen, image=image, background='white')
            label_i.grid(row=0, column=5, columnspan=2, rowspan=7, padx=10, pady=40)

            screen_width = screen.winfo_screenwidth()
            screen_height = screen.winfo_screenheight()
            w_width = 900
            w_height = 600
            center_x = int(screen_width / 2 - w_width / 2)
            center_y = int(screen_height / 2 - w_height / 2)
            screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

            sno = record[0]
            uid = record[1]
            name = record[2]
            age = record[3]
            test_type = record[4]
            date = record[5]
            result = record[6]
            remarks = record[7]

            label0 = tk.Label(screen, text='Serial No: ' + str(sno) + '\n', background='white',
                              font=('Times', 13, 'bold'))
            label0.grid(row=0, column=0, padx=30, pady=20, sticky='w')

            label1 = tk.Label(screen, text='Unique Id: ' + str(uid) + '\n', background='white',
                              font=('Times', 13, 'bold'))
            label1.grid(row=1, column=0, padx=30, pady=20, sticky='w')

            label2 = tk.Label(screen, text='Name: ' + name + '\n', background='white', font=('Times', 13, 'bold'))
            label2.grid(row=2, column=0, padx=30, pady=20, sticky='w')

            label3 = tk.Label(screen, text='Age: ' + str(age) + '\n', background='white', font=('Times', 13, 'bold'))
            label3.grid(row=3, column=0, padx=30, pady=20, sticky='w')

            label4 = tk.Label(screen, text='Test Type: ' + test_type + '\n', background='white',
                              font=('Times', 13, 'bold'))
            label4.grid(row=4, column=0, padx=30, pady=20, sticky='w')

            label5 = tk.Label(screen, text='Date: ' + date + '\n', background='white', font=('Times', 13, 'bold'))
            label5.grid(row=5, column=0, padx=30, pady=20, sticky='w')

            label6 = tk.Label(screen, text='Result: ' + result + '\n', background='white', font=('Times', 13, 'bold'))
            label6.grid(row=6, column=0, padx=30, pady=20, sticky='w')

            label7 = tk.Label(screen, text='Remarks: ' + remarks + '\n', background='white', font=('Times', 13, 'bold'))
            label7.grid(row=7, column=0, padx=30, pady=20, sticky='w')

            screen.mainloop()

    # Buttons
    button1 = tk.Button(screen, text='Search', width=10, background='#f84477', foreground='white',
                        font=('Times', 11, 'bold'), command=search_button)
    button1.grid(row=5, column=1, padx=20, pady=10)

    screen.mainloop()


def recent_tests():
    import tkinter as tk
    from tkinter import ttk
    import mysql.connector
    from db_conn import db
    cursor = db.cursor()
    # record(ID, Name, Age, type , date varchar,result,remarks
    cursor.execute('SELECT * FROM record ORDER BY Sno DESC LIMIT 1;')
    records = cursor.fetchall()

    count = 0
    for record in records:
        if count < 1:
            uid = record[1]
            name = record[2]
            age = record[3]
            test_type = record[4]
            date = record[5]
            result = record[6]
            remarks = record[7]

            screen = tk.Toplevel()
            screen.configure(background='white')
            screen.title('Recent Test')
            image = tk.PhotoImage(file='img/report.png')
            screen.iconphoto(True, image)
            screen.iconname('pathology')
            screen.configure(background='white')
            image1 = tk.PhotoImage(file='img/report.png')

            def menu():
                # Menu developed by abdul Muhaimin

                menubar = tk.Menu(screen)
                # Adding File Menu and commands
                file = tk.Menu(menubar, tearoff=0)
                menubar.add_cascade(label='File', menu=file)

                def logout():
                    screen.destroy()

                    import Login

                file.add_command(label='Logout', command=logout)
                file.add_separator()
                file.add_command(label='Exit', command=screen.destroy)

                # Adding Help Menu
                patients_ = tk.Menu(menubar, tearoff=0)

                menubar.add_cascade(label='Records', menu=patients_)

                patients_.add_command(label='Add Record', command=add_record)

                patients_.add_command(label='Recent Test', command=recent_tests)
                patients_.add_separator()

                patients_.add_command(label='Search Record', command=search_record)
                patients_.add_command(label='remove Record', command=remove_record)
                screen.config(menu=menubar)
                # Menu developed by abdul Muhaimin

            menu()

            label = ttk.Label(screen, image=image1, background='white')
            label.grid(row=1, column=2, rowspan=4, padx=40, pady=10)

            screen_width = screen.winfo_screenwidth()
            screen_height = screen.winfo_screenheight()
            w_width = 900
            w_height = 600
            center_x = int(screen_width / 2 - w_width / 2)
            center_y = int(screen_height / 2 - w_height / 2)
            screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

            label1 = tk.Label(screen, text='Unique Id: ' + str(uid) + '\n', background='white',
                              font=('Times', 13, 'bold'))
            label1.grid(row=0, column=0, padx=30, pady=20, sticky='w')

            label2 = tk.Label(screen, text='Name: ' + name + '\n', background='white', font=('Times', 13, 'bold'))
            label2.grid(row=1, column=0, padx=30, pady=20, sticky='w')

            label3 = tk.Label(screen, text='Age: ' + str(age) + '\n', background='white', font=('Times', 13, 'bold'))
            label3.grid(row=2, column=0, padx=30, pady=20, sticky='w')

            label4 = tk.Label(screen, text='Test Type: ' + test_type + '\n', background='white',
                              font=('Times', 13, 'bold'))
            label4.grid(row=3, column=0, padx=30, pady=20, sticky='w')

            label5 = tk.Label(screen, text='Date: ' + date + '\n', background='white', font=('Times', 13, 'bold'))
            label5.grid(row=4, column=0, padx=30, pady=20, sticky='w')

            label6 = tk.Label(screen, text='Result: ' + result + '\n', background='white', font=('Times', 13, 'bold'))
            label6.grid(row=5, column=0, padx=30, pady=20, sticky='w')

            label7 = tk.Label(screen, text='Remarks: ' + remarks + '\n', background='white', font=('Times', 13, 'bold'))
            label7.grid(row=6, column=0, padx=30, pady=20, sticky='w')

            count += 1

            screen.mainloop()
