#Developer= <-------Nazzal Kausar------>

import mysql.connector
from db_conn import db
cursor=db.cursor()

import tkinter as tk
from tkinter import ttk




def add_drug():
    from db_conn import db
    cursor=db.cursor()
    
    global screen
    screen= tk.Toplevel()
    screen.configure(background='white')

    #title&icon
    screen.title('Add Drug')
    image=tk.PhotoImage(file='img/drug.png')
    screen.iconphoto(True,image)
    screen.iconname('add_drug')

    #screen centering

    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()
    w_width = 900
    w_height = 600
    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)
    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')
    screen.resizable(False,False)

    image1=tk.PhotoImage(file='img/drug.png')
    label=ttk.Label(screen,image=image1,background='white')
    label.grid(row=1,column=2,rowspan=4,columnspan=2,pady=60,padx=60)

    #Name label and entry
    label1=tk.Label(screen,text='Name',background='white',font=('Times',12,'bold'))
    label1.grid(row=1,column=0,padx=20,pady=40,sticky='w')

    entry1=ttk.Entry(screen,background='white')
    entry1.grid(row=1,column=1,padx=20,ipadx=15,sticky='w',pady=40)

    #Price label and entry
    label2=tk.Label(screen,text='Price',background='white',font=('Times',12,'bold'))
    label2.grid(row=2,column=0,padx=20,pady=40,sticky='w')

    entry2=ttk.Entry(screen,background='white')
    entry2.grid(row=2,column=1,padx=20,ipadx=15,sticky='w',pady=40)

    #Quantity label and entry
    label3=tk.Label(screen,text='Quantity',background='white',font=('Times',12,'bold'))
    label3.grid(row=3,column=0,padx=20,pady=40,sticky='w')

    entry3=ttk.Entry(screen,background='white')
    entry3.grid(row=3,column=1,padx=20,ipadx=15,sticky='w',pady=40)

    #Type label and entry
    label4=tk.Label(screen,text='Type',background='white',font=('Times',12,'bold'))
    label4.grid(row=4,column=0,padx=20,pady=40,sticky='w')

    entry4=ttk.Entry(screen,background='white')
    entry4.grid(row=4,column=1,padx=20,pady=40,ipadx=15,sticky='w')

    #function to add drug
    def add():
        name=entry1.get()
        price=entry2.get()
        quantity=entry3.get()
        type=entry4.get()
        cursor.execute('INSERT INTO drug(name,price,quantity,type) VALUES(%s,%s,%s,%s)',(name,price,quantity,type))
        db.commit()
        entry1.delete(0,tk.END)
        entry2.delete(0,tk.END)
        entry3.delete(0,tk.END)
        entry4.delete(0,tk.END)
        screen=tk.Toplevel()
        screen.configure(background='white')
        screen.title('Check Drug')
        image=tk.PhotoImage(file='img/check-drug.png')
        screen.iconphoto(True,image)
        screen.iconname('available_drug')
        screen_width = screen.winfo_screenwidth()
        screen_height = screen.winfo_screenheight()
        w_width = 200
        w_height = 200
        center_x = int(screen_width / 2 - w_width / 2)
        center_y = int(screen_height / 2 - w_height / 2)
        screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')
        screen.resizable(False,False)
        label=ttk.Label(screen,text='Drug is Added!',background='white',font=('Times',16,'bold'),foreground='green')
        label.grid(row=1,column=1,padx=30,pady=40)
        button=tk.Button(screen,text='OK',background='#f84477',foreground='white',font=('Times',12,'bold'),command=screen.destroy)
        button.grid(row=2,column=1,padx=50,pady=20,ipadx=15)
        screen.mainloop()

        

    #Button to update the database
    button1=tk.Button(screen,text='Add',background='#f84477',foreground='white',font=('Times',12,'bold'),command=add)
    button1.grid(row=5,column=1,padx=20,pady=40, ipadx= 30)



    screen.mainloop()
    

def available_drug():
    from db_conn import db
    cursor=db.cursor()
    
    global screen
    screen= tk.Toplevel()
    screen.configure(background='white')

    #title&icon
    screen.title('Check Drug')
    image=tk.PhotoImage(file='img/check-drug.png')
    screen.iconphoto(True,image)
    screen.iconname('check_drug')
    
    #label
    label=ttk.Label(screen,text='Drugs Available',background='white',font=('Times',20,'bold'),foreground='#f84477')
    label.pack(pady=20)

    #screen centering

    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()
    w_width = 900
    w_height = 600
    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)
    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')
    screen.resizable(False,False)

    #treeview to show the available drug
    tree=ttk.Treeview(screen,columns=('Sno','name','price','quantity','type'),show='headings')
    tree.pack(fill='y',pady=10)

    tree.heading('Sno',text='Sno')
    tree.heading('name',text='Name')
    tree.heading('price',text='Price')
    tree.heading('quantity',text='Quantity')
    tree.heading('type',text='Type')
    tree.column('#0',width=0,minwidth=0,stretch=tk.NO)
    tree.column('Sno',width=100,minwidth=100,stretch=tk.NO)
    tree.column('name',width=100,minwidth=100,stretch=tk.NO)
    tree.column('price',width=100,minwidth=100,stretch=tk.NO)
    tree.column('quantity',width=100,minwidth=100,stretch=tk.NO)
    tree.column('type',width=100,minwidth=100,stretch=tk.NO)

    cursor.execute('SELECT * FROM drug')
    data=cursor.fetchall()
    for i in data:
        tree.insert('',0,values=i)

    style = ttk.Style()
    style.theme_use("clam")

    style.configure("Treeview",
                    background="white",
                    foreground="black",
                    rowheight=40,
                    fieldbackground="white",
                    color='white',)

    #Change selected color:
    style.map("Treeview",
            background=[('selected', '#f84477')])
    style.configure("Treeview.Heading",
                    background="white",
                    foreground="black",
                    font=('Times',12,'bold'))

    #scrollbar for treeview
    scrollbar=ttk.Scrollbar(screen,orient='vertical',command=tree.yview)
    scrollbar.place(y=40,x=882,height=430,width=20)
    tree.configure(yscrollcommand=scrollbar.set)


    screen.mainloop()    

def lacking_drug():
    from db_conn import db
    cursor=db.cursor()

    global screen
    import tkinter as tk
    from tkinter import ttk
    screen= tk.Toplevel()
    screen.configure(background='white')

    #title&icon
    screen.title('Lacking Drug')
    image=tk.PhotoImage(file='img/check-drug.png')
    screen.iconphoto(True,image)
    screen.iconname('lacking_drug')

    #screen centering
    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()
    w_width = 900
    w_height = 600
    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)
    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')
    screen.resizable(False,False)

    # image1=tk.PhotoImage(file='img/check-drug.png')
    # label=ttk.Label(screen,image=image1,background='white')
    # label.pack(side='top',anchor='center',pady=0)

    cursor.execute('SELECT * FROM drug where quantity<=200')
    data=cursor.fetchall()
    my_tree=ttk.Treeview(screen,columns=('Sno','Name','Price','Quantity','Type'),show='headings',selectmode='extended')
    my_tree.pack(side='top',anchor='center',padx=20,pady=40)
    my_tree.heading('Sno',text='Sno')
    my_tree.heading('Name',text='Name')
    my_tree.heading('Type',text='Type')
    my_tree.heading('Quantity',text='Quantity')
    my_tree.heading('Price',text='Price')
    my_tree.column('#0',stretch=tk.NO,minwidth=0,width=0,anchor='center')
    my_tree.column('#1',stretch=tk.NO,minwidth=0,width=100,anchor='center')
    my_tree.column('#2',stretch=tk.NO,minwidth=0,width=100,anchor='center')
    my_tree.column('#3',stretch=tk.NO,minwidth=0,width=100,anchor='center')
    my_tree.column('#4',stretch=tk.NO,minwidth=0,width=100,anchor='center')
    my_tree.column('#5',stretch=tk.NO,minwidth=0,width=100,anchor='center')
    for i in range(len(data)):
        my_tree.insert('',i,values=data[i])

    style = ttk.Style()
    style.theme_use("clam")

    style.configure("Treeview",
                    background="white",
                    foreground="black",
                    rowheight=40,
                    fieldbackground="white",
                    color='white',)

    #Change selected color:
    style.map("Treeview",
            background=[('selected', '#f84477')])
    style.configure("Treeview.Heading",
                    background="white",
                    foreground="black",
                    font=('Times',12,'bold'))

    #scrollbar for treeview
    scrollbar=ttk.Scrollbar(screen,orient='vertical',command=my_tree.yview)
    scrollbar.place(y=40,x=882,height=430,width=20)
    my_tree.configure(yscrollcommand=scrollbar.set)

    button=tk.Button(screen,text='OK',background='#f84477',foreground='white',font=('Times',12,'bold'),command=screen.destroy)
    button.pack(side='top',anchor='center',padx=20,ipadx=20,ipady=3)
    screen.mainloop()
    
def order_drug():
    from db_conn import db
    cursor=db.cursor()

    import tkinter as tk
    from tkinter import ttk
    screen= tk.Toplevel()
    
    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()
    w_width = 900
    w_height = 600
    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)
    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')
    screen.resizable(False,False)
    screen.configure(background='white')
    screen.title('Order Drug')
    image=tk.PhotoImage(file='img/drug.png')
    screen.iconphoto(True,image)
    screen.iconname('order_drug')

    label=ttk.Label(screen,text='Lacking Drugs',background='white',foreground='#f84477',font=('Cooper black',20))
    label.grid(row=0,column=2,padx=70,pady=20,ipadx=15,columnspan=3,sticky='e')

    #Name label and entry
    label1=tk.Label(screen,text='Name',background='white',foreground='black',font=('Times',12,'bold'))
    label1.grid(row=1,column=0,padx=20,pady=40,ipadx=10)
    entry1=tk.Entry(screen,background='white',foreground='black',font=('Times',12,'bold'))
    entry1.grid(row=1,column=1,padx=20,pady=40)

    #Type label and entry
    label2=tk.Label(screen,text='Type',background='white',foreground='black',font=('Times',12,'bold'))
    label2.grid(row=2,column=0,padx=20,pady=40)
    entry2=tk.Entry(screen,background='white',foreground='black',font=('Times',12,'bold'))
    entry2.grid(row=2,column=1,padx=20,pady=40)

    #Quantity label and entry
    label3=tk.Label(screen,text='Quantity',background='white',foreground='black',font=('Times',12,'bold'))
    label3.grid(row=3,column=0,padx=20,pady=40)
    entry3=tk.Entry(screen,background='white',foreground='black',font=('Times',12,'bold'))
    entry3.grid(row=3,column=1,padx=20,pady=40)

    #function for order drug
    def order():
        screen=tk.Toplevel()
        
        screen_width = screen.winfo_screenwidth()
        screen_height = screen.winfo_screenheight()
        w_width = 300
        w_height = 200
        center_x = int(screen_width / 2 - w_width / 2)
        center_y = int(screen_height / 2 - w_height / 2)
        screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')
        screen.resizable(False,False)
        screen.configure(background='white')

        screen.title('Success')
        image=tk.PhotoImage(file='img/drug.png')
        screen.iconphoto(True,image)
        screen.iconname('success')
        label=ttk.Label(screen,text='Successfully Ordered!',background='white',foreground='green',font=('Times',16,'bold'))
        label.grid(row=0,column=0,padx=40,pady=20,ipadx=10)
        button=tk.Button(screen,text='OK',background='#f84477',foreground='white',font=('Times',12,'bold'),command=screen.destroy)
        button.grid(row=1,column=0,padx=20,pady=40,ipadx=20)
        screen.mainloop()

    #order button
    button=tk.Button(screen,text='Order',background='#f84477',foreground='white',font=('Times',12,'bold'),command=order)
    button.grid(row=4,column=1,padx=20,pady=20)

    #lacking drugs treeview
    cursor.execute('SELECT * FROM drug where quantity<=200')
    data=cursor.fetchall()
    my_tree=ttk.Treeview(screen,columns=('Sno','Name','Price','Quantity','Type'),show='headings',selectmode='extended')
    my_tree.grid(row=1,column=2,padx=20,pady=20,columnspan=4,rowspan=5)
    my_tree.heading('Sno',text='Sno')
    my_tree.heading('Name',text='Name')
    my_tree.heading('Type',text='Type')
    my_tree.heading('Quantity',text='Quantity')
    my_tree.heading('Price',text='Price')
    my_tree.column('#0',stretch=tk.NO,minwidth=0,width=0,anchor='center')
    my_tree.column('#1',stretch=tk.NO,minwidth=0,width=100,anchor='center')
    my_tree.column('#2',stretch=tk.NO,minwidth=0,width=100,anchor='center')
    my_tree.column('#3',stretch=tk.NO,minwidth=0,width=100,anchor='center')
    my_tree.column('#4',stretch=tk.NO,minwidth=0,width=100,anchor='center')
    my_tree.column('#5',stretch=tk.NO,minwidth=0,width=100,anchor='center')
    for i in range(len(data)):
        my_tree.insert('',i,values=data[i])

    style = ttk.Style()
    style.theme_use("clam")

    style.configure("Treeview",
                    background="white",
                    foreground="black",
                    rowheight=40,
                    fieldbackground="white",
                    color='white',)

    #Change selected color:
    style.map("Treeview",
            background=[('selected', '#f84477')])
    style.configure("Treeview.Heading",
                    background="white",
                    foreground="black",
                    font=('Times',12,'bold'))

    #scrollbar for treeview
    scrollbar=ttk.Scrollbar(screen,orient='vertical',command=my_tree.yview)
    scrollbar.place(y=40,x=882,height=430,width=20)
    my_tree.configure(yscrollcommand=scrollbar.set)

    #enter the selected drug in the entrys
    def my_tree_select(event):
        global selected_drug
        selected_drug=my_tree.selection()
        selected_drug1=my_tree.item(selected_drug)
        selected_drug2=selected_drug1['values']

        entry1.delete(0,tk.END)
        entry1.insert(0,selected_drug2[1]) #name
        entry2.delete(0,tk.END)
        entry2.insert(0,selected_drug2[4]) #type
        entry3.delete(0,tk.END)
        entry3.insert(0,selected_drug2[3]) #quantity
    my_tree.bind('<<TreeviewSelect>>',my_tree_select)

    screen.mainloop()

        
def drug_details():
    from db_conn import db
    cursor=db.cursor()

    import tkinter as tk
    from tkinter import ttk
    screen= tk.Toplevel()

    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()
    w_width = 900
    w_height = 600
    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)
    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')
    screen.resizable(False,False)
    screen.configure(background='white')

    screen.title('Drug Details')

    image=tk.PhotoImage(file='img/medicine-record.png')
    screen.iconphoto(True,image)
    screen.iconname('drug-record')

    my_tree=ttk.Treeview(screen,columns=('Sno','Name','Price','Quantity','Type'),show='headings',selectmode='extended')
    my_tree.grid(row=1,column=2,padx=50,pady=20,columnspan=4,rowspan=5)
    my_tree.heading('Sno',text='Sno')
    my_tree.heading('Name',text='Name')
    my_tree.heading('Type',text='Type')
    my_tree.heading('Quantity',text='Quantity')
    my_tree.heading('Price',text='Price')
    my_tree.column('#0',stretch=tk.NO,minwidth=0,width=0,anchor='center')
    my_tree.column('#1',stretch=tk.NO,minwidth=0,width=100,anchor='center')
    my_tree.column('#2',stretch=tk.NO,minwidth=0,width=100,anchor='center')
    my_tree.column('#3',stretch=tk.NO,minwidth=0,width=100,anchor='center')
    my_tree.column('#4',stretch=tk.NO,minwidth=0,width=100,anchor='center')
    my_tree.column('#5',stretch=tk.NO,minwidth=0,width=100,anchor='center')
    
    #Name of the drug
    label=ttk.Label(screen,text='Name',background='white',foreground='#f84477',font=('Times',11,'bold'))
    label.grid(row=2,column=0,padx=20,pady=30,sticky='w')
    entry1=ttk.Entry(screen)
    entry1.grid(row=2,column=1,pady=30,sticky='w')

    #Type of the drug
    label=ttk.Label(screen,text='Type',background='white',foreground='#f84477',font=('Times',11,'bold'))
    label.grid(row=3,column=0,padx=20,pady=20,ipadx=30,sticky='w')
    entry2=ttk.Entry(screen)
    entry2.grid(row=3,column=1,pady=30,sticky='w')

    #function to get the details
    def get_details():
        name=entry1.get()
        type=entry2.get()
        cursor.execute('SELECT * FROM drug where name=%s and type=%s',(name,type))
        data=cursor.fetchall()

        for i in range(len(data)):
            my_tree.insert('',i,values=data[i])

        style = ttk.Style()
        style.theme_use("clam")

        style.configure("Treeview",
                        background="white",
                        foreground="black",
                        rowheight=40,
                        fieldbackground="white",
                        color='white',)

        #Change selected color:
        style.map("Treeview",

                background=[('selected', '#f84477')])   #Change selected color: 
        style.configure("Treeview.Heading",
                        background="white",
                        foreground="black",
                        font=('Times',12,'bold'))

    button=tk.Button(screen,text='Get Details',command=get_details,width=12,font=('Times',11,'bold'),background='#f84477',foreground='white')
    button.grid(row=4,column=1,padx=10,pady=10,sticky='w')
    screen.mainloop()


