
# Developed and designed By Abdul Muhaimin
from tkinter import messagebox
import tkinter as tk

scroll_bar = tk.Scrollbar()

scroll_bar.pack(side=tk.RIGHT,
                fill=tk.Y)

mylist = tk.Listbox(yscrollcommand = scroll_bar.set, width=155)

messagebox.showinfo("showinfo", "Fetching Data")

from db_conn import db
mycursor = db.cursor()

mycursor.execute("SELECT * FROM EM_patient")

myresult = mycursor.fetchall()

for x in myresult:
  mylist.insert(tk.END, x )


