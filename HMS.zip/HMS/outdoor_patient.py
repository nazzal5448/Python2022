# developer= 'Nazzal Kausar'
def op_reg():
    import tkinter as tk
    from tkinter import ttk
    import shortuuid as uuid
    from tkinter import messagebox
    screen = tk.Toplevel()
    screen.title('Receiptionist / OutPatient')
    image = tk.PhotoImage(file='img/logo.png')
    screen.iconphoto(False, image)
    screen_label = ttk.Label(screen, text='OutPatient Registration Form', font=('Cooper Black', 22),
                             foreground='#f84477',
                             background='white')
    screen_label.grid(row=0, column=1, columnspan=5)

    # MenuBar

    # Menu developed by abdul Muhaimin

    menubar = tk.Menu(screen)
    # Adding File Menu and commands
    file = tk.Menu(menubar, tearoff=0)
    menubar.add_cascade(label='File', menu=file)

    def logout():
        screen.destroy()

        import Login

    file.add_command(label='Logout', command=logout)
    file.add_separator()
    file.add_command(label='Exit', command=screen.destroy)

    # Adding Help Menu
    patients_ = tk.Menu(menubar, tearoff=0)
    menubar.add_cascade(label='patients', menu=patients_)

    def ip():
        import inpatient_reg

    patients_.add_command(label='In-Patient', command=ip)

    patients_.add_command(label='Outdoor-patients')
    patients_.add_separator()

    def emr():
        import Emergency_reg

    patients_.add_command(label='Emergency Patients', command=emr)

    def dis():
        import discharging



    Others_ = tk.Menu(menubar, tearoff=0)
    Others_.add_command(label='Discharge Patients', command=dis)
    menubar.add_cascade(label='Others', menu=Others_)

    def ds():
        import daily_shifts
    Others_.add_command(label='Daily Shifts', command=ds)

    screen.config(menu=menubar)
    # Menu developed by abdul Muhaimin

    # screen1 centering
    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()

    w_width = 900
    w_height = 600

    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)

    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

    # screen1 centering
    screen.configure(bg='white')

    # patient id label and field
    id = uuid.ShortUUID().random(length=5)
    def insert_data():
        messagebox.showinfo("showinfo", "Saving Data...")

        import mysql.connector
        from db_conn import db

        mycursor = db.cursor()

        name = entry_2.get()
        gender = var.get()
        con = entry_4.get()
        age = entry_7.get()

        sql = "INSERT INTO Out_patient (PatientId, Name, Gender, Contact, Age ) VALUES (%s, %s, %s, %s, %s)"
        val = (id, name, gender, con, age)
        mycursor.execute(sql, val)

        db.commit()

        messagebox.showinfo("showinfo", "Data Saved")
        print(mycursor.rowcount, "record inserted.")

    label_1 = ttk.Label(screen, text='Patient Id', background='white')
    label_1.grid(row=1, column=0, padx=20, pady=30, sticky='w')


    entry_1 = ttk.Entry(screen, width=15)
    entry_1.grid(row=1, column=1, sticky='w')
    entry_1.insert(0, id)
    entry_1.config(state="disabled")


    # Name label and field
    label_2 = ttk.Label(screen, text='Name', background='white')
    label_2.grid(row=2, column=0, padx=20, pady=30, sticky='w')

    entry_2 = ttk.Entry(screen, width=15, font='Helvetica')
    entry_2.grid(row=2, column=1, columnspan=3, sticky='w')

    # Gender label and menu
    label_3 = tk.Label(screen, text='Gender', background='white')
    label_3.grid(row=3, column=0, padx=20, sticky='w')

    options = [
        'Select Gender',
        'Male',
        'Female',
        'Custom'
    ]

    var = tk.StringVar()
    var.set('Select gender')
    gender = ttk.OptionMenu(screen, var, *options)
    gender.grid(row=3, column=1, sticky='w', pady=30)

    # Contact label and field
    label_4 = ttk.Label(screen, text='Contact No', background='white')
    label_4.grid(row=4, column=0, padx=20, pady=30, sticky='w')

    entry_4 = ttk.Entry(screen, width=20)
    entry_4.grid(row=4, column=1, sticky='w', pady=30)

    # Doctor label and field
    label_5 = ttk.Label(screen, text='Doctor', background='white')
    label_5.grid(row=5, column=0, padx=20, sticky='w', pady=30)

    entry_5 = ttk.Entry(screen, width=20)
    entry_5.grid(row=5, column=1, sticky='w')

    # Date label and field
    label_6 = ttk.Label(screen, text='Date', background='white')
    label_6.grid(row=1, column=4, padx=20, sticky='w', pady=30)

    entry_6 = ttk.Entry(screen)
    entry_6.grid(row=1, column=5, sticky='w')

    # Age label and field
    label_7 = ttk.Label(screen, text='Age', background='white')
    label_7.grid(row=2, column=4, padx=20, sticky='w', pady=30)

    entry_7 = ttk.Entry(screen)
    entry_7.grid(row=2, column=5, sticky='w')

    # empty label
    label8 = ttk.Label(screen, text='           ', background='white')
    label8.grid(row=6, column=0, pady=15)

    # Buttons
    save = tk.Button(screen, text='Save', width=10, border=2, background='#f84477', foreground='white', command=insert_data)
    save.grid(row=7, column=1, padx=15, pady=30)


    # frame=tk.Frame(screen,width=50,height=40,borderwidth=5)
    # frame.grid(row=3,column=5,rowspan=4)

    screen.mainloop()


op_reg()
