#Developer= <-------Nazzal Kausar------>

def pharmacy():
    import tkinter as tk
    from tkinter import ttk
    import pharmacy_modules as pm
    global screen1
    screen1= tk.Toplevel()
    screen1.configure(background='white')

    #title&icon
    screen1.title('Pharmacy')
    image=tk.PhotoImage(file='img/pharmacy.png')
    screen1.iconphoto(True,image)
    screen1.iconname('employee')

    #screen centering
    screen1_width = screen1.winfo_screenwidth()
    screen1_height = screen1.winfo_screenheight()
    w_width = 900
    w_height = 600
    center_x = int(screen1_width / 2 - w_width / 2)
    center_y = int(screen1_height / 2 - w_height / 2)
    screen1.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')
    screen1.resizable(False,False)

    image1=tk.PhotoImage(file='img/pharmacy.png')
    label=ttk.Label(screen1,image=image1,background='white')
    label.grid(row=1,column=0,rowspan=4,columnspan=2,pady=80,padx=80,sticky='e')
    label1=ttk.Label(screen1, text='Welcome To Drug Management System'
        ,background='white',foreground='#f84477',font=('Cooper Black', 16))
    
    label1.grid(row=0,column=3,columnspan=3,padx=10,pady=10)
    label2=tk.Label(screen1,text='               ',background='white')
    label2.grid(row=1,column=3,rowspan=6,padx=10)

    #Buttons
    button1=tk.Button(screen1,text='Available Drugs',background='#f84477',foreground='white',font=('Times',11,'bold'),command=pm.available_drug)
    button1.grid(row=1,column=4,padx=10,pady=10,ipadx=26)

    button2=tk.Button(screen1,text='Lacking Drugs',background='#f84477',foreground='white',font=('Times',11,'bold'),command=pm.lacking_drug)
    button2.grid(row=2,column=4,padx=10,pady=10,ipadx=30)

    button3=tk.Button(screen1,text='Order Drugs',background='#f84477',foreground='white',font=('Times',11,'bold'),command=pm.order_drug)
    button3.grid(row=3,column=4,padx=10,pady=10,ipadx=38)

    button4=tk.Button(screen1,text='Drug Details',background='#f84477',foreground='white',font=('Times',11,'bold'),command=pm.drug_details)
    button4.grid(row=4,column=4,padx=10,pady=10,ipadx=39)

    button5=tk.Button(screen1,text='Add Drug',background='#f84477',foreground='white',font=('Times',11,'bold'),command=pm.add_drug)
    button5.grid(row=5,column=4,padx=10,pady=33,ipadx=49)
    screen1.mainloop()

pharmacy()