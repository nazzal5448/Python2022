# Developer= <--------Nazzal Kausar-------->

import mysql.connector

from db_conn import db
cursor = db.cursor()


def employee_entry():
    from db_conn import db
    cursor = db.cursor()
    import tkinter as tk
    from tkinter import ttk
    import uuid
    screen = tk.Toplevel()
    screen.configure(background='white')
    screen.title('Employee Entry')

    global image
    image = tk.PhotoImage(file='img/registration-form.png')
    screen.iconphoto(False, image)

    label_i = tk.Label(screen, image=image, background='white')
    label_i.grid(row=0, column=5, columnspan=2, rowspan=7, padx=30, pady=40)

    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()
    w_width = 900
    w_height = 600
    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)
    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

    label0 = ttk.Label(screen, text='Employee Entry', background='white', foreground='#f84477',
                       font=('Cooper Black', 20))
    label0.grid(row=0, column=4, columnspan=2, padx=20, sticky='s')

    # Id label And Entry

    label1 = tk.Label(screen, text='Unique ID', background='white', font=('Times', 12, 'bold'))
    label1.grid(row=1, column=0, padx=20, pady=20, sticky='w')

    entry1 = ttk.Entry(screen, background='white')
    entry1.grid(row=1, column=1, padx=20, pady=20, ipadx=15, sticky='w')
    uid = uuid.uuid4()
    x = str(uid)[:4]
    entry1.insert(0, x)
    entry1.configure(state='disabled')

    # Name label and entry

    label2 = tk.Label(screen, text='Name', background='white', font=('Times', 12, 'bold'))
    label2.grid(row=2, column=0, padx=20, pady=20, sticky='w')

    entry2 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry2.grid(row=2, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # Age label and entry
    label3 = tk.Label(screen, text='Age', background='white', font=('Times', 12, 'bold'))
    label3.grid(row=3, column=0, padx=20, pady=20, sticky='w')

    entry3 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry3.grid(row=3, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # Department label and entry
    label4 = tk.Label(screen, text='Department', background='white', font=('Times', 12, 'bold'))
    label4.grid(row=4, column=0, padx=20, pady=20, sticky='w')

    entry4 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry4.grid(row=4, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # Salary label and entry
    label5 = tk.Label(screen, text='Basic salary', background='white', font=('Times', 12, 'bold'))
    label5.grid(row=5, column=0, padx=20, pady=20, sticky='w')

    entry5 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry5.grid(row=5, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # Qualification label and entry
    label6 = tk.Label(screen, text='Qualification', background='white', font=('Times', 12, 'bold'))
    label6.grid(row=6, column=0, padx=20, pady=20, sticky='w')

    entry6 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry6.grid(row=6, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # blank label
    label7 = tk.Label(screen, text='                ', background='white')
    label7.grid(row=0, column=3, rowspan=6, padx=20, ipadx=30)

    def add():
        data = (entry1.get(), entry2.get(), entry3.get(), entry4.get(), entry5.get(), entry6.get())
        entry1.delete(0, 'end')
        entry2.delete(0, 'end')
        entry3.delete(0, 'end')
        entry4.delete(0, 'end')
        entry5.delete(0, 'end')
        entry6.delete(0, 'end')

        query = ('insert into employee(ID, Name, Age , department, salary,qualification) Values(%s,%s,%s,%s,%s,%s)')

        cursor.execute(query, data)
        db.commit()
        screen.quit()

    # Buttons
    button1 = tk.Button(screen, text='Add Employee', width=10, background='#f84477', foreground='white',
                        font=('Times', 11, 'bold'), command=add)
    button1.grid(row=7, column=1, padx=20, pady=10)

    screen.mainloop()


def employee_removal():
    from db_conn import db
    cursor = db.cursor()
    cursor.execute('select * from employee LIMIT  0,5')
    records = cursor.fetchall()

    import tkinter as tk
    from tkinter import ttk
    screen = tk.Toplevel()
    screen.configure(background='white')
    screen.title('Employee Removal')

    global image
    image = tk.PhotoImage(file='img/remove-user.png')
    screen.iconphoto(False, image)

    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()
    w_width = 900
    w_height = 600
    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)
    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

    my_tree = ttk.Treeview(screen, columns=(1, 2, 3, 4, 5, 6, 7), show='headings', selectmode='extended')
    my_tree.grid(row=1, column=3, columnspan=3, rowspan=7, padx=40, pady=20)

    my_tree.column(1, width=40, anchor='center')
    my_tree.column(2, width=50, anchor='center')
    my_tree.column(3, width=90, anchor='center')
    my_tree.column(4, width=40, anchor='center')
    my_tree.column(5, width=85, anchor='center')
    my_tree.column(6, width=48, anchor='center')
    my_tree.column(7, width=100, anchor='center')

    my_tree.heading(1, text='Sno')
    my_tree.heading(2, text='ID')
    my_tree.heading(3, text='Name')
    my_tree.heading(4, text='Age')
    my_tree.heading(5, text='Department')
    my_tree.heading(6, text='Salary')
    my_tree.heading(7, text='Qualification')

    for record in records:
        my_tree.insert((''), 'end', iid=record[0],
                       values=(record[0], record[1], record[2], record[3], record[4], record[5], record[6]))

        # function to enter selected row in entry fields
        def get_selected_row(event):
            try:
                global selected_row
                index = my_tree.selection()
                selected_row = my_tree.item(index)
                selected_row = selected_row['values']
                entry1.delete(0, 'end')
                entry2.delete(0, 'end')
                entry2.insert(0, selected_row[2])
                entry3.delete(0, 'end')
                entry3.insert(0, selected_row[4])
                entry4.delete(0, 'end')
                entry4.insert(0, selected_row[6])
            except IndexError:
                pass

        my_tree.bind('<<TreeviewSelect>>', get_selected_row)

    style = ttk.Style()
    style.theme_use("clam")

    style.configure("Treeview",
                    background="white",
                    foreground="black",
                    rowheight=55,
                    fieldbackground="white",
                    color='white', )

    # Change selected color:
    style.map("Treeview",
              background=[('selected', '#f84477')])

    label0 = ttk.Label(screen, text='Employee Removal', background='white', foreground='#f84477',
                       font=('Cooper Black', 20))
    label0.grid(row=0, column=0, columnspan=2, padx=20, sticky='s')

    # Id label And Entry

    label1 = tk.Label(screen, text='Unique ID', background='white', font=('Times', 12, 'bold'))
    label1.grid(row=1, column=0, padx=20, pady=10, sticky='w')

    entry1 = ttk.Entry(screen, background='white')
    entry1.grid(row=1, column=1, padx=20, ipadx=15, sticky='w')

    def search():
        query = entry1.get()
        selections = []
        for child in my_tree.get_children():
            if query in my_tree.item(child)['values']:
                selections.append(child)
            my_tree.selection_set(selections)

    button1 = tk.Button(screen, text='Search', width=10, background='#f84477', foreground='white',
                        font=('Times', 11, 'bold'), command=search)
    button1.grid(row=2, column=1, padx=20, pady=5)

    # Name label and entry

    label2 = tk.Label(screen, text='Name', background='white', font=('Times', 12, 'bold'))
    label2.grid(row=3, column=0, padx=20, pady=20, sticky='w')

    entry2 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry2.grid(row=3, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # Department label and entry
    label3 = tk.Label(screen, text='Department', background='white', font=('Times', 12, 'bold'))
    label3.grid(row=4, column=0, padx=20, pady=20, sticky='w')

    entry3 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry3.grid(row=4, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # Qualification label and entry
    label4 = tk.Label(screen, text='Qualification', background='white', font=('Times', 12, 'bold'))
    label4.grid(row=5, column=0, padx=20, pady=20, sticky='w')

    entry4 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry4.grid(row=5, column=1, padx=20, pady=20, ipadx=15, sticky='w')
    # blank label
    label5 = tk.Label(screen, text='                ', background='white')
    label5.grid(row=0, column=3, rowspan=6, padx=20, ipadx=30)

    def remove_button():
        cursor.execute(f"DELETE FROM employee where ID = '{entry1.get()}'")
        db.commit()
        entry1.delete(0, 'end')
        entry2.delete(0, 'end')
        entry3.delete(0, 'end')
        entry4.delete(0, 'end')

    # Buttons
    button2 = tk.Button(screen, text='Remove', width=10, background='#f84477', foreground='white',
                        font=('Times', 11, 'bold'), command=remove_button)
    button2.grid(row=6, column=1, padx=20, pady=20)

    screen.mainloop()


def employee_department():
    from db_conn import db
    cursor = db.cursor()
    import tkinter as tk
    from tkinter import ttk
    screen = tk.Toplevel()
    screen.configure(background='white')
    screen.title('Employee Department')

    global image
    image = tk.PhotoImage(file='img/search-place.png')
    screen.iconphoto(False, image)

    label_i = tk.Label(screen, image=image, background='white')
    label_i.grid(row=0, column=4, columnspan=2, rowspan=7, padx=30, pady=40)

    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()
    w_width = 900
    w_height = 600
    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)
    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

    label0 = ttk.Label(screen, text='Find Department', background='white', foreground='#f84477',
                       font=('Cooper Black', 20))
    label0.grid(row=0, column=4, columnspan=2, padx=20, sticky='s')

    # Id label And Entry

    label1 = tk.Label(screen, text='Unique ID', background='white', font=('Times', 12, 'bold'))
    label1.grid(row=1, column=0, padx=20, pady=20, sticky='w')

    entry1 = ttk.Entry(screen, background='white')
    entry1.grid(row=1, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # Name label and entry

    label2 = tk.Label(screen, text='Name', background='white', font=('Times', 12, 'bold'))
    label2.grid(row=2, column=0, padx=20, pady=20, sticky='w')

    entry2 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry2.grid(row=2, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # Qualification label and entry
    label3 = tk.Label(screen, text='Qualification', background='white', font=('Times', 12, 'bold'))
    label3.grid(row=3, column=0, padx=20, pady=20, sticky='w')

    entry3 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry3.grid(row=3, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # blank label
    label5 = tk.Label(screen, text='                ', background='white')
    label5.grid(row=0, column=3, rowspan=6, padx=20, ipadx=30)

    def search():
        cursor.execute(f"SELECT * FROM employee where ID = '{entry1.get()}'")
        records = cursor.fetchall()
        for record in records:
            screen = tk.Toplevel()
            screen.configure(background='white')
            screen.title('Search Employee')

            global image
            image = tk.PhotoImage(file='img/search-place.png')
            screen.iconphoto(False, image)

            label_i = tk.Label(screen, image=image, background='white')
            label_i.grid(row=0, column=3, columnspan=2, rowspan=7, padx=10, pady=40)

            screen_width = screen.winfo_screenwidth()
            screen_height = screen.winfo_screenheight()
            w_width = 900
            w_height = 600
            center_x = int(screen_width / 2 - w_width / 2)
            center_y = int(screen_height / 2 - w_height / 2)
            screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

            sno = record[0]
            uid = record[1]
            name = record[2]
            age = record[3]
            department = record[4]
            salary = record[5]
            qualification = record[6]

            label0 = tk.Label(screen, text='Serial No: ' + str(sno) + '\n', background='white',
                              font=('Times', 13, 'bold'))
            label0.grid(row=0, column=0, padx=30, pady=20, sticky='w')

            label1 = tk.Label(screen, text='Unique Id: ' + str(uid) + '\n', background='white',
                              font=('Times', 13, 'bold'))
            label1.grid(row=1, column=0, padx=30, pady=20, sticky='w')

            label2 = tk.Label(screen, text='Name: ' + name + '\n', background='white', font=('Times', 13, 'bold'))
            label2.grid(row=2, column=0, padx=30, pady=20, sticky='w')

            label3 = tk.Label(screen, text='Age: ' + str(age) + '\n', background='white', font=('Times', 13, 'bold'))
            label3.grid(row=3, column=0, padx=30, pady=20, sticky='w')

            label4 = tk.Label(screen, text='Department: ' + department + '\n', background='white',
                              font=('Times', 13, 'bold'))
            label4.grid(row=4, column=0, padx=30, pady=20, sticky='w')

            label5 = tk.Label(screen, text='Salary: ' + str(salary) + ' Rs\n', background='white',
                              font=('Times', 13, 'bold'))
            label5.grid(row=5, column=0, padx=30, pady=20, sticky='w')

            label6 = tk.Label(screen, text='Qualification: ' + qualification + '\n', background='white',
                              font=('Times', 13, 'bold'))
            label6.grid(row=6, column=0, padx=30, pady=20, sticky='w')

            screen.mainloop()

    # Buttons
    button1 = tk.Button(screen, text='Search', width=10, background='#f84477', foreground='white',
                        font=('Times', 11, 'bold'), command=search)
    button1.grid(row=4, column=1, padx=20, pady=20)

    screen.mainloop()


def generate_payroll():
    from db_conn import db
    cursor = db.cursor()
    import tkinter as tk
    from tkinter import ttk
    screen = tk.Toplevel()
    screen.configure(background='white')
    screen.title('Generate Payroll')

    global image
    image = tk.PhotoImage(file='img/salaryslip.png')
    screen.iconphoto(False, image)

    label_i = tk.Label(screen, image=image, background='white')
    label_i.grid(row=1, column=5, columnspan=2, rowspan=7, pady=40, sticky='w')

    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()
    w_width = 900
    w_height = 600
    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)
    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

    label0 = ttk.Label(screen, text='Payroll Generator', background='white', foreground='#f84477',
                       font=('Cooper Black', 20))
    label0.grid(row=0, column=3, columnspan=2, padx=20, sticky='s')

    # Id label And Entry

    label1 = tk.Label(screen, text='Unique ID', background='white', font=('Times', 12, 'bold'))
    label1.grid(row=1, column=0, padx=20, pady=20, sticky='w')

    entry1 = ttk.Entry(screen, background='white')
    entry1.grid(row=1, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # Name label and entry

    label2 = tk.Label(screen, text='Name', background='white', font=('Times', 12, 'bold'))
    label2.grid(row=2, column=0, padx=20, pady=20, sticky='w')

    entry2 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry2.grid(row=2, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # Qualification label and entry
    label3 = tk.Label(screen, text='Qualification', background='white', font=('Times', 12, 'bold'))
    label3.grid(row=3, column=0, padx=20, pady=20, sticky='w')

    entry3 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry3.grid(row=3, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # department label and entry
    label4 = tk.Label(screen, text='Department', background='white', font=('Times', 12, 'bold'))
    label4.grid(row=4, column=0, padx=20, pady=20, sticky='w')

    entry4 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry4.grid(row=4, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # Basic pay label and field
    label5 = tk.Label(screen, text='Basic Pay', background='white', font=('Times', 12, 'bold'))
    label5.grid(row=5, column=0, padx=20, pady=20, sticky='w')

    entry5 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry5.grid(row=5, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # loans label and field
    label6 = tk.Label(screen, text='Loans', background='white', font=('Times', 12, 'bold'))
    label6.grid(row=6, column=0, padx=20, pady=20, sticky='w')

    entry6 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry6.grid(row=6, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # Other charges label and field
    label7 = tk.Label(screen, text='Other Charges', background='white', font=('Times', 12, 'bold'))
    label7.grid(row=7, column=0, padx=20, pady=20, sticky='w')

    entry7 = ttk.Entry(screen, background='white', font=('Times', 10))
    entry7.grid(row=7, column=1, padx=20, pady=20, ipadx=15, sticky='w')

    # blank label
    label5 = tk.Label(screen, text='         ', background='white')
    label5.grid(row=0, column=3, rowspan=6, padx=10, ipadx=10)

    def generate():
        cursor.execute(f"SELECT * FROM employee where ID = '{entry1.get()}'")
        records = cursor.fetchall()
        for record in records:
            screen = tk.Toplevel()
            screen.configure(background='white')
            screen.title('Generate Salary')

            global image
            image = tk.PhotoImage(file='img/salaryslip.png')
            screen.iconphoto(False, image)

            label_i = tk.Label(screen, image=image, background='white')
            label_i.grid(row=0, column=5, columnspan=2, rowspan=7, padx=10, pady=40)

            screen_width = screen.winfo_screenwidth()
            screen_height = screen.winfo_screenheight()
            w_width = 900
            w_height = 600
            center_x = int(screen_width / 2 - w_width / 2)
            center_y = int(screen_height / 2 - w_height / 2)
            screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

            sno = record[0]
            uid = record[1]
            name = record[2]
            age = record[3]
            department = record[4]
            salary = int(entry5.get())
            qualification = record[6]
            loans = entry6.get()
            other_charges = entry7.get()



            label0 = tk.Label(screen, text='Serial No: ' + str(sno) + '\n', background='white',
                              font=('Times', 13, 'bold'))
            label0.grid(row=0, column=0, padx=30, pady=20, sticky='w')

            label1 = tk.Label(screen, text='Unique Id: ' + str(uid) + '\n', background='white',
                              font=('Times', 13, 'bold'))
            label1.grid(row=1, column=0, padx=30, pady=20, sticky='w')

            label2 = tk.Label(screen, text='Name: ' + name + '\n', background='white', font=('Times', 13, 'bold'))
            label2.grid(row=2, column=0, padx=30, pady=20, sticky='w')

            label3 = tk.Label(screen, text='Age: ' + str(age) + '\n', background='white', font=('Times', 13, 'bold'))
            label3.grid(row=3, column=0, padx=30, pady=20, sticky='w')

            label4 = tk.Label(screen, text='Department: ' + department + '\n', background='white',
                              font=('Times', 13, 'bold'))
            label4.grid(row=4, column=0, padx=30, pady=20, sticky='w')

            label5 = tk.Label(screen, text='Salary: ' + str(salary) + ' Rs \n', background='white',
                              font=('Times', 13, 'bold'))
            label5.grid(row=5, column=0, padx=30, pady=20, sticky='w')

            label6 = tk.Label(screen, text='Qualification: ' + qualification + '\n', background='white',
                              font=('Times', 13, 'bold'))
            label6.grid(row=6, column=0, padx=30, pady=20, sticky='w')

            label7 = tk.Label(screen, text='Loans: ' + str(entry6.get()) + ' Rs\n', background='white',
                              font=('Times', 13, 'bold'))
            label7.grid(row=0, column=1, padx=20, pady=20, sticky='w')

            label8 = tk.Label(screen, text='Other Charges: ' + str(entry7.get()) + ' Rs\n', background='white',
                              font=('Times', 13, 'bold'))
            label8.grid(row=6, column=0, padx=30, pady=20, sticky='w')

            charges = int(entry7.get()) + int(entry6.get())
            pay = salary - charges


            tax = float(pay) * 0.02
            net_pay = pay - tax

            mycursor = db.cursor()

            sql = "INSERT INTO payroll (uid, Name, Age, department, salary, qualification, loans, other_charges, tax, net_pay) VALUES (%s, %s, %s, %s, %s, %s, %s,%s, %s, %s)"
            val = (uid, name, age, department, salary, qualification, loans, other_charges, tax, net_pay)
            mycursor.execute(sql, val)

            db.commit()

            print(mycursor.rowcount, "record inserted.")

            label8 = tk.Label(screen, text='Taxes: ' + str(tax) + ' Rs \n', background='white',
                              font=('Times', 13, 'bold'))
            label8.grid(row=1, column=1, padx=20, pady=10, sticky='w')

            label9 = tk.Label(screen, text='Net Pay: ' + str(net_pay) + ' Rs\n', background='white',
                              font=('Times', 13, 'bold'))
            label9.grid(row=2, column=1, padx=20, pady=10, sticky='w')


            screen.mainloop()

    # Buttons
    button1 = tk.Button(screen, text='Generate', width=10, background='#f84477', foreground='white',
                        font=('Times', 11, 'bold'), command=generate)
    button1.grid(row=8, column=1, padx=20, pady=20)

    screen.mainloop()

