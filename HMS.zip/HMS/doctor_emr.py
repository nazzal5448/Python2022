# Whole created Abdul Muhaimin

# Developed and designed By Abdul Muhaimin

import tkinter as tk
import uuid
from tkinter import ttk


screen = tk.Toplevel()
screen.title('Doctor / Emergency Patients')
global logo
logo = tk.PhotoImage(file="img/medical-file.png")
screen.iconphoto(False, logo)
screen.configure(bg='white')

# Menu developed by abdul Muhaimin

menubar = tk.Menu(screen)
# Adding File Menu and commands
file = tk.Menu(menubar, tearoff=0)
menubar.add_cascade(label='File', menu=file)

def logout():
    screen.destroy()

    import Login


def Home():
    import doctor

file.add_command(label='Home', command=Home)
file.add_command(label='Logout', command=logout)
file.add_separator()
file.add_command(label='Exit', command=screen.destroy)

# Adding Help Menu
patients_ = tk.Menu(menubar, tearoff=0)

menubar.add_cascade(label='Treat patients', menu=patients_)


def ipTreat():
    import doctor_indoor

patients_.add_command(label='Treat In-Patient', command=ipTreat)

def OPTreat():
    import doctor_emr

patients_.add_command(label='Treat Outdoor-patients', command=OPTreat)
patients_.add_separator()



patients_.add_command(label='Treat Emergency Patients')
screen.config(menu=menubar)
# Menu developed by abdul Muhaimin

# screen1 centering
screen_width = screen.winfo_screenwidth()
screen_height = screen.winfo_screenheight()

w_width = 900
w_height = 600

center_x = int(screen_width / 2 - w_width / 2)
center_y = int(screen_height / 2 - w_height / 2)

screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

# screen1 centering

# code starts here

Frame1 = tk.Frame(screen, width=450, height=600, background='white')
Frame1.pack(side=tk.LEFT, padx=55)

Label = ttk.Label(Frame1, text='Patient Treated', font=("Arial Black", 12), background='white')
Label.grid(columnspan=2)

label_1 = ttk.Label(Frame1, text='Patient Id', background='white')
label_1.grid(row=1, column=0, padx=20, pady=30, sticky='w')

uid=uuid.uuid4()
patient_id =str(uid)[:4]
entry_1 = ttk.Entry(Frame1,   width=15)
entry_1.grid(row=1, column=1, sticky='w')
entry_1.insert(0, patient_id)

# Name label and field
label_2 = ttk.Label(Frame1, text='Name', background='white')
label_2.grid(row=2, column=0, padx=20, pady=30, sticky='w')

entry_2 = ttk.Entry(Frame1, width=15, font='Helvetica')
entry_2.grid(row=2, column=1, columnspan=3, sticky='w')

# Contact label and field
label_3 = ttk.Label(Frame1, text='What is Caused?', background='white')
label_3.grid(row=3, column=0, padx=20, pady=30, sticky='w')

entry_3 = ttk.Entry(Frame1, width=20)
entry_3.grid(row=3, column=1, sticky='w', pady=30)


# Date label and field
label_4 = ttk.Label(Frame1, text='Prescription', background='white')
label_4.grid(row=4, column=0, padx=20, sticky='w', pady=30)

entry_4 = ttk.Entry(Frame1)
entry_4.grid(row=4, column=1, sticky='w')
# Buttons

def save_data():
    # mycursor = db.cursor()
    # mycursor.execute('create table treated_patients (id varchar (200), name varchar (200), cause varchar (200), prescription varchar (200) )')
    id = entry_1.get()
    name = entry_2.get()
    cause= entry_3.get()
    prescription = entry_4.get()
    mycursor = db.cursor()

    sql = "INSERT INTO treated_patients (id, name, cause, prescription) VALUES (%s, %s, %s, %s)"
    val = (id, name, cause, prescription)
    mycursor.execute(sql, val)


    db.commit()

    entry_1.delete(0, tk.END)
    entry_2.delete(0, tk.END)
    entry_3.delete(0, tk.END)
    entry_4.delete(0, tk.END)
    print(mycursor.rowcount, "record inserted.")




save = tk.Button(Frame1, text='Save', command=save_data, width=15, border=2, background='#f84477', foreground='white')
save.grid(row=7, column=1, padx=15, pady=10)


def admit():
    screen = tk.Toplevel()

    w_width = 450
    w_height = 350

    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)

    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')
    screen.configure(bg="white")

    # screen1 centering

    # code starts here
    _lable1 = tk.Label(screen, text="Id", bg="white")
    _lable1.pack(pady=(25, 15))

    entry_lable1 = tk.Entry(screen)
    entry_lable1.pack()
    entry_lable1.insert(0, patient_id)

    _lable2 = tk.Label(screen, text="Name", bg="white")
    _lable2.pack(pady=(25, 15))

    entry_lable2 = tk.Entry(screen)
    entry_lable2.pack()

    _lable3 = tk.Label(screen, text="Days", bg="white")
    _lable3.pack(pady=(25, 15))

    entry_lable3 = tk.Entry(screen)
    entry_lable3.pack()

    def save_admit():
        from db_conn import db
        mycursor = db.cursor()

        sql = "INSERT INTO admitted (id, Name, admit_days) VALUES (%s, %s, %s)"
        val = (patient_id, entry_lable2.get(), entry_lable3.get())
        mycursor.execute(sql, val)

        db.commit()

        print(mycursor.rowcount, "record inserted.")

    _btn = tk.Button(screen, text="submit", width=15,  background='#f84477',fg="white", command=save_admit)
    _btn.pack(pady=(25, 15))

    screen.mainloop()





btn1 = tk.Button(Frame1, text='Admit Patient', width=15, background='#f84477', foreground='white', command=admit)
btn1.grid(row=8, column=1, )



Label = ttk.Label(screen, text='Patient Entered', font=("Arial Black", 12), background='white')
Label.pack()

from db_conn import db
cursor = db.cursor()
cursor.execute('select * from EM_patient LIMIT  0,5')
records = cursor.fetchall()


frame2 = tk.Frame(screen)
frame2.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
frame2.configure(bg="white")

my_tree = ttk.Treeview(frame2, columns=(1, 2, 3, 4), show='headings', selectmode='browse')
my_tree.pack(side='left')

my_tree.column(1, width=120, anchor='center')
my_tree.column(2, width=120, anchor='center')
my_tree.column(3, width=120, anchor='center')
my_tree.column(4, width=120, anchor='center')

my_tree.heading(1, text='Id')
my_tree.heading(2, text='name')
my_tree.heading(3, text='Emergency')
my_tree.heading(4, text='Doctor')


for record in records:
    my_tree.insert((''), 'end', iid=record[0],
                   values=(record[0], record[1], record[2], record[3]))

style = ttk.Style()
style.theme_use("clam")

style.configure("Treeview",
                background="white",
                foreground="black",
                rowheight=55,
                fieldbackground="white",
                color='white', )

verscrlbar = ttk.Scrollbar(frame2,
                           orient="vertical",
                           command=my_tree.yview)
my_tree.configure(yscrollcommand=verscrlbar.set)

verscrlbar.pack(side=tk.LEFT, fill='y', expand=True)


screen.mainloop()