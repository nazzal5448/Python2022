# Developed and designed By Abdul Muhaimin
import shortuuid as uuid


def em_reg():
    import tkinter as tk
    from tkinter import ttk
    import shortuuid as uuid
    from tkinter import messagebox

    screen = tk.Toplevel()
    screen.title('Receiptionist / Emergency')
    image = tk.PhotoImage(file='img/logo.png')
    screen.iconphoto(False, image)

    # Menu developed by abdul Muhaimin

    menubar = tk.Menu(screen)
    # Adding File Menu and commands
    file = tk.Menu(menubar, tearoff=0)
    menubar.add_cascade(label='File', menu=file)

    def logout():
        screen.destroy()

        import Login

    file.add_command(label='Logout', command=logout)
    file.add_separator()
    file.add_command(label='Exit', command=screen.destroy)

    # Adding Help Menu
    patients_ = tk.Menu(menubar, tearoff=0)

    menubar.add_cascade(label='patients', menu=patients_)


    def ip():
        import inpatient_reg

    patients_.add_command(label='In-Patient', command=ip)

    def op():
        import outdoor_patient

    patients_.add_command(label='Outdoor-patients', command=op)
    patients_.add_separator()



    patients_.add_command(label='Emergency Patients')

    Others_ = tk.Menu(menubar, tearoff=0)

    menubar.add_cascade(label='Others', menu=Others_)

    def ds():
        import daily_shifts
    Others_.add_command(label='Daily Shifts', command=ds)

    def dis():
        import discharging

    Others_.add_command(label='Discharge Patients', command=dis)

    screen.config(menu=menubar)

    # Menu developed by abdul Muhaimin


    # screen1 centering
    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()

    w_width = 900
    w_height = 600

    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)

    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

    # screen1 centering

    screen.configure(bg='white')

    # code starts here
    img = tk.PhotoImage(file='img/emergency.png')
    label1 = ttk.Label(screen, image=img, background="white")
    label1.image = img
    label1.pack()

    screen_label = ttk.Label(screen, text='Emergency Registration Form', font=('Cooper Black', 22),
                             foreground='#f84477',
                             background='white')
    screen_label.pack()

    frame1 = tk.Frame(screen, width=355, height=355, bg="white")
    frame1.pack()

    # entries
    en_label1 = tk.Label(frame1, text='ID', bg='white')
    en_label1.grid(row=0, column=0)
    id = uuid.ShortUUID().random(length=5)

    def insert_data():

        messagebox.showinfo("showinfo", "Saving Data...")

        import mysql.connector
        from db_conn import db

        mycursor = db.cursor()

        name = entry_2.get()
        em = entry_3.get()
        d_assign = entry_4.get()

        sql = "INSERT INTO EM_patient (PatientId, name, Emergency, d_assign ) VALUES (%s, %s, %s, %s)"
        val = (id, name, em, d_assign)
        mycursor.execute(sql, val)

        db.commit()

        messagebox.showinfo("showinfo", "Data Saved")
        print(mycursor.rowcount, "record inserted.")
    entry_1 = ttk.Entry(frame1)
    entry_1.grid(row=1, column=0, pady=(0, 50), padx=10)
    entry_1.insert(0, id)
    entry_1.config(state='disabled')

    en_label2 = tk.Label(frame1, text='Patient Name', bg='white')
    en_label2.grid(row=0, column=1)
    entry_2 = ttk.Entry(frame1)
    entry_2.grid(row=1, column=1, pady=(0, 50), padx=10)

    en_label3 = tk.Label(frame1, text='Emergency Problem', bg='white')
    en_label3.grid(row=2, column=0, padx=10)

    entry_3 = ttk.Entry(frame1)
    entry_3.grid(row=3, column=0, padx=10)

    en_label4 = tk.Label(frame1, text='Doctor Assigned', bg='white')
    en_label4.grid(row=2, column=1, padx=10)
    entry_4 = ttk.Entry(frame1)
    entry_4.grid(row=3, column=1, padx=10)

    btn = tk.Button(screen,text='Submit', command=insert_data)
    btn.pack(pady=15)

    screen.mainloop()


em_reg()
