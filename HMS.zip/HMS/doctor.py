# Whole created Abdul Muhaimin

# Developed and designed By Abdul Muhaimin
# from 
# from PIL import ImageTk, Image

import tkinter as tk
from tkinter import ttk

screen = tk.Toplevel()
screen.title('Doctor')
global logo
logo = tk.PhotoImage(file="img/doctor.png")
screen.iconphoto(False, logo)
screen.configure(bg='white')
# screen1 centering
screen_width = screen.winfo_screenwidth()
screen_height = screen.winfo_screenheight()

w_width = 900
w_height = 600

center_x = int(screen_width / 2 - w_width / 2)
center_y = int(screen_height / 2 - w_height / 2)

screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

# screen1 centering

# Code start Here
img = tk.PhotoImage(file='img/doctor.png')
label1 = ttk.Label(screen, image=img, background="white")
label1.image = img
label1.pack()

screen_label = ttk.Label(screen, text='Hello! Doctor', font=('Cooper Black', 22),
                         foreground='#f84477',
                         background='white')
screen_label.pack()

Buttons = tk.Frame(screen, width=355, height=355, bg="white")
Buttons.pack()


def op_patient():
    import doctor_indoor


btn1 = tk.Button(Buttons, text="OutDoor Patients", width=15, font=("Arial Black", 8), background="#f84477",
                 foreground="white",
                 cursor="hand2",
                 command=op_patient)
btn1.pack(padx=55, pady=(35, 12))


def ip_patient():
    import doctor_indoor


btn2 = tk.Button(Buttons, text="InDoor Patients", width=15, font=("Arial Black", 8), background="#f84477",
                 foreground="white", cursor="hand2", command=ip_patient)
btn2.pack(padx=55, pady=(35, 12))


def emr_patient():
    import doctor_emr


btn2 = tk.Button(Buttons, text="Emergency Patients", width=15, font=("Arial Black", 8), background="#f84477",
                 foreground="white", cursor="hand2", command=emr_patient)
btn2.pack(padx=55, pady=(35, 12))

def profile():
    import view_profile

btn3 = tk.Button(Buttons, text="View Profile", width=15, font=("Arial Black", 8), background="#f84477",
                 foreground="white", cursor="hand2", command=profile)
btn3.pack(padx=55, pady=(35, 15))


screen.mainloop()
