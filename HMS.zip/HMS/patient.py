import mysql.connector
db=mysql.connector.connect(host='localhost',user='root',password='5448',database='hospital')
cursor=db.cursor()
cursor.execute('show tables')
table=cursor.fetchall()
print(table)
