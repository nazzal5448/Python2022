from db_conn import db

cursor = db.cursor()

import tkinter as tk
from tkinter import ttk
from tkinter import messagebox


screen = tk.Toplevel()

screen_width = screen.winfo_screenwidth()
screen_height = screen.winfo_screenheight()
w_width = 900
w_height = 600
center_x = int(screen_width / 2 - w_width / 2)
center_y = int(screen_height / 2 - w_height / 2)
screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')
screen.resizable(False, False)
screen.configure(background='white')
screen.title('Change Password')
image = tk.PhotoImage(file='img/hospital.png')
screen.iconphoto(True, image)
screen.iconname('Hospital')



label = ttk.Label(screen, text='Change Password', background='white', foreground='#f84477', font=('Cooper black', 20))
label.grid(row=0, column=2, padx=70, pady=5, ipadx=15, columnspan=3, sticky='e')

# Type label and entry

label1 = tk.Label(screen, text='New Password', background='white', foreground='black', font=('Times', 12, 'bold'))
label1.grid(row=2, column=0, padx=20, pady=5)
entry1 = tk.Entry(screen, background='white', foreground='black', font=('Times', 12, 'bold'))
entry1.grid(row=2, column=1, padx=20, pady=5)

label2 = tk.Label(screen, text='Previous Password', background='white', foreground='black', font=('Times', 12, 'bold'))
label2.grid(row=3, column=0, padx=20, pady=5)
entry2 = tk.Entry(screen, background='white', foreground='black', font=('Times', 12, 'bold'))
entry2.grid(row=3, column=1, padx=20, pady=5)



# Dropdown menu options
options = [
    "Select Role",
    "Admin",
    "Accountant",
    "Doctor",
    "Pathology",
    "receiptionist",
    "Pharmacy",

]

# datatype of menu text
clicked = tk.StringVar()

# initial menu text

# Create Dropdown menu
drop = ttk.OptionMenu(screen, clicked, *options)
drop.grid(row=4, column=0, padx=(55, 0), pady=5)

# order button

def change():
    messagebox.showinfo("showinfo", "Signing In")
    import db_conn as db
    # Data Transfer code
    # Developed By Abdul Muhaimin

    # admin
    if clicked.get() == "Admin":
        print("you are admin")


        # Fecthing password from sql
        cursor2 = db.db.cursor()
        cursor2.execute("Select password From admin_data ")
        pass_db = cursor2.fetchall()
        print("pass:", pass_db)

        # getting user's provided password
        pass_word = entry2.get()

        for j in pass_db[0]:
            print("db_pass:", j)
            print("pass:", pass_word, "\n", "________________", "\n")

            if j == pass_word:
                n_pass = entry1.get()

                mycursor = db.db.cursor()
                sql = f"UPDATE admin_data SET password = '{n_pass}'"
                mycursor.execute(sql)

                screen.update()

                db.db.commit()

                print(mycursor.rowcount, "record(s) affected")


            else:
                messagebox.showwarning("showwarning", "Wrong Previous Password")
    # admin

    # accountant
    elif clicked.get() == "Accountant":
        print("you are Accountant")


        # Fecthing password from sql
        cursor2 = db.db.cursor()
        cursor2.execute("Select password From accountant_data ")
        pass_db = cursor2.fetchall()
        print("pass:", pass_db)

        # getting user's provided password
        pass_word = entry2.get()

        for j in pass_db[0]:
            print("db_pass:", j)
            print("pass:", pass_word, "\n", "________________", "\n")

            if j == pass_word:
                n_pass = entry1.get()

                mycursor = db.db.cursor()
                sql = f"UPDATE accountant_data SET password = '{n_pass}'"
                mycursor.execute(sql)

                screen.update()

                db.db.commit()

                print(mycursor.rowcount, "record(s) affected")

            else:
                messagebox.showwarning("showwarning", "Wrong Previous Password")
    # accountant

    # doctor
    elif clicked.get() == "Doctor":
        print("you are Doctor")

        # Fecthing password from sql
        cursor2 = db.db.cursor()
        cursor2.execute("Select password From doctor_data ")
        pass_db = cursor2.fetchall()
        print("pass:", pass_db)

        # getting user's provided password
        pass_word = entry2.get()

        for j in pass_db[0]:
            print("db_pass:", j)
            print("pass:", pass_word, "\n", "________________", "\n")

            if j == pass_word:
                n_pass = entry1.get()

                mycursor = db.db.cursor()
                sql = f"UPDATE doctor_data SET password = '{n_pass}'"
                mycursor.execute(sql)

                screen.update()

                db.db.commit()

                print(mycursor.rowcount, "record(s) affected")

            else:
                messagebox.showwarning("showwarning", "Wrong Previous Password")

    # doctor

    # pharmacy
    elif clicked.get() == "Pharmacy":
        print("you are pharmacist")

        # Fecthing password from sql
        cursor2 = db.db.cursor()
        cursor2.execute("Select password From pharmacy_data ")
        pass_db = cursor2.fetchall()
        print("pass:", pass_db)

        # getting user's provided password
        pass_word = entry2.get()

        for j in pass_db[0]:
            print("db_pass:", j)
            print("pass:", pass_word, "\n", "________________", "\n")

            if j == pass_word:
                n_pass = entry1.get()

                mycursor = db.db.cursor()
                sql = f"UPDATE pharmacy_data SET password = '{n_pass}'"
                mycursor.execute(sql)

                screen.update()

                db.db.commit()

                print(mycursor.rowcount, "record(s) affected")

            else:
                messagebox.showwarning("showwarning", "Wrong Previous Password")
    # pharmacy

    # receiptionist
    elif clicked.get() == "receiptionist":
        print("you are receiptionist")

        # Fecthing password from sql
        cursor2 = db.db.cursor()
        cursor2.execute("Select password From receiptionist_data ")
        pass_db = cursor2.fetchall()
        print("pass:", pass_db)

        # getting user's provided password
        pass_word = entry2.get()

        for j in pass_db[0]:
            print("db_pass:", j)
            print("pass:", pass_word, "\n", "________________", "\n")

            if j == pass_word:
                n_pass = entry1.get()

                mycursor = db.db.cursor()
                sql = f"UPDATE receiptionist_data SET password = '{n_pass}'"
                mycursor.execute(sql)

                screen.update()

                db.db.commit()
                messagebox.showinfo("showinfo", "Wrong Previous Password")
                print(mycursor.rowcount, "record(s) affected")

            else:
                messagebox.showwarning("showwarning", "Wrong Previous Password")
    # receiptionist

    # pathology
    elif clicked.get() == "Pathology":
        print("you are Pathologist")

        # Fecthing password from sql
        cursor2 = db.db.cursor()
        cursor2.execute("Select password From Pathology_data ")
        pass_db = cursor2.fetchall()
        print("pass:", pass_db)

        # getting user's provided password
        pass_word = entry2.get()

        for j in pass_db[0]:
            print("db_pass:", j)
            print("pass:", pass_word, "\n", "________________", "\n")

            if j == pass_word:
                n_pass = entry1.get()

                mycursor = db.db.cursor()
                sql = f"UPDATE Pathology_data SET password = '{n_pass}'"
                mycursor.execute(sql)

                screen.update()

                db.db.commit()

                print(mycursor.rowcount, "record(s) affected")

            else:
                messagebox.showwarning("showwarning", "Wrong Previous Password")
    # pathology



    else:
        messagebox.showwarning("showwarning", "Select Role!")



button1 = tk.Button(screen, text='change', background='#f84477', foreground='white', font=('Times', 12, 'bold'), command=change)
button1.grid(row=4, column=1, pady=5)

# function for order drug




# lacking drugs treeview
cursor.execute('SELECT * FROM receiptionist_data')
data1 = cursor.fetchall()
cursor.execute('SELECT * FROM pharmacy_data')
data2 = cursor.fetchall()
cursor.execute('SELECT * FROM accountant_data')
data3 = cursor.fetchall()
cursor.execute('SELECT * FROM admin_data')
data4 = cursor.fetchall()
cursor.execute('SELECT * FROM doctor_data')
data5 = cursor.fetchall()
cursor.execute('SELECT * FROM Pathology_data')
data6 = cursor.fetchall()
my_tree = ttk.Treeview(screen, columns=("username", "password"), show='headings',
                       selectmode='extended')
my_tree.grid(row=1, column=2, padx=20, pady=20, columnspan=4, rowspan=5)
my_tree.heading('username', text='username')
my_tree.heading('password', text='password')

for i in range(len(data1)):
    my_tree.insert('', i, values=data1[i])

for i in range(len(data2)):
    my_tree.insert('', i, values=data2[i])

for i in range(len(data3)):
    my_tree.insert('', i, values=data3[i])

for i in range(len(data4)):
    my_tree.insert('', i, values=data4[i])

for i in range(len(data5)):
    my_tree.insert('', i, values=data5[i])

for i in range(len(data6)):
    my_tree.insert('', i, values=data6[i])

style = ttk.Style()
style.theme_use("clam")

style.configure("Treeview",
                background="white",
                foreground="black",
                rowheight=40,
                fieldbackground="white",
                color='white', )

# Change selected color:
style.map("Treeview",
          background=[('selected', '#f84477')])
style.configure("Treeview.Heading",
                background="white",
                foreground="black",
                font=('Times', 12, 'bold'))

# scrollbar for treeview
scrollbar = ttk.Scrollbar(screen, orient='vertical', command=my_tree.yview)
scrollbar.place(y=40, x=882, height=430, width=20)
my_tree.configure(yscrollcommand=scrollbar.set)

screen.mainloop()
