# Screen designer = 'Nazzal Kausar'
import shortuuid as uuid
from PIL import ImageTk, Image


def ip_reg():
    import tkinter as tk
    from tkinter import ttk
    from tkinter import messagebox
    screen = tk.Toplevel()
    screen.title('Receiptionist / InPatient')
    global logo
    logo = ImageTk.PhotoImage(Image.open("img/logo.png"))
    screen.iconphoto(False, logo)
    screen_label = ttk.Label(screen, text='InPatient Registration Form', font=('Cooper Black', 22)
                             , foreground='#f84477', background='white')

    screen_label.grid(row=0, column=1, columnspan=5)

    screen.configure(bg='white')

    # MenuBar

    # Menu developed by abdul Muhaimin

    menubar = tk.Menu(screen)
    # Adding File Menu and commands
    file = tk.Menu(menubar, tearoff=0)
    menubar.add_cascade(label='File', menu=file)

    def logout():
        screen.destroy()

        import Login

    file.add_command(label='Logout', command=logout)
    file.add_separator()
    file.add_command(label='Exit', command=screen.destroy)

    # Adding Help Menu
    patients_ = tk.Menu(menubar, tearoff=0)
    menubar.add_cascade(label='patients', menu=patients_)
    patients_.add_command(label='In-Patient')

    def op():
        import outdoor_patient

    patients_.add_command(label='Outdoor-patients', command=op)
    patients_.add_separator()

    def emr():
        import Emergency_reg

    patients_.add_command(label='Emergency Patients', command=emr)
    Others_ = tk.Menu(menubar, tearoff=0)

    menubar.add_cascade(label='Others', menu=Others_)

    def ds():
        import daily_shifts
    Others_.add_command(label='Daily Shifts', command=ds)

    def dis():
        import discharging

    Others_.add_command(label='Discharge Patients', command=dis)

    screen.config(menu=menubar)
    # Menu developed by abdul Muhaimin

    # screen1 centering
    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()

    w_width = 900
    w_height = 600

    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)

    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

    # screen1 centering
    id = uuid.ShortUUID().random(length=5)
    # patient id label and field
    def insert_data():
        messagebox.showinfo("showinfo", "Saving Data...")

        import mysql.connector
        from db_conn import db

        mycursor = db.cursor()

        name = entry_2.get()
        gender = var.get()
        con = entry_4.get()
        age = entry_7.get()

        sql = "INSERT INTO In_patient (PatientId, Name, Gender, Contact, Age ) VALUES (%s, %s, %s, %s, %s)"
        val = (id, name, gender, con, age)
        mycursor.execute(sql, val)

        db.commit()

        messagebox.showinfo("showinfo", "Data Saved")
        print(mycursor.rowcount, "record inserted.")

    label_1 = ttk.Label(screen, text='Patient Id', background='white')
    label_1.grid(row=1, column=0, padx=20, pady=30, sticky='w')


    entry_1 = ttk.Entry(screen, width=15)
    entry_1.grid(row=1, column=1, sticky='w')
    entry_1.insert(0, id)

    # Name label and field
    label_2 = ttk.Label(screen, text='Name', background='white')
    label_2.grid(row=2, column=0, padx=20, pady=30, sticky='w')

    entry_2 = ttk.Entry(screen, width=15, font='Helvetica')
    entry_2.grid(row=2, column=1, columnspan=3, sticky='w')
    # Gender label and menu
    label_3 = tk.Label(screen, text='Gender', background='white')
    label_3.grid(row=3, column=0, padx=20, sticky='w')

    options = [
        "Select Gender",
        'Male',
        'Female',
        'Custom'
    ]

    var = tk.StringVar()

    var.set('Select gender')
    gender = ttk.OptionMenu(screen, var, *options)
    gender.grid(row=3, column=1, sticky='w', pady=30)

    # Contact label and field
    label_4 = ttk.Label(screen, text='Contact No', background='white')
    label_4.grid(row=4, column=0, padx=20, pady=30, sticky='w')

    entry_4 = ttk.Entry(screen, width=20)
    entry_4.grid(row=4, column=1, sticky='w', pady=30)

    # Doctor label and field
    label_5 = ttk.Label(screen, text='Doctor', background='white')
    label_5.grid(row=5, column=0, padx=20, sticky='w', pady=30)

    entry_5 = ttk.Entry(screen, width=20)
    entry_5.grid(row=5, column=1, sticky='w')

    # Date label and field
    label_6 = ttk.Label(screen, text='Date', background='white')
    label_6.grid(row=1, column=4, padx=20, sticky='w', pady=30)

    entry_6 = ttk.Entry(screen)
    entry_6.grid(row=1, column=5, sticky='w')

    # Age label and field
    label_7 = ttk.Label(screen, text='Age', background='white')
    label_7.grid(row=2, column=4, padx=20, sticky='w', pady=30)

    entry_7 = ttk.Entry(screen)
    entry_7.grid(row=2, column=5, sticky='w')

    # address label and widget
    label_8 = ttk.Label(screen, background='white', text='Address')
    label_8.grid(row=3, column=4, padx=20, sticky='w')

    entry_8 = tk.Text(screen, highlightthickness=2, highlightcolor='black', background='white', height=5, width=20)
    entry_8.grid(row=3, column=5, sticky='w', pady=10)

    # room label and menu
    label_9 = ttk.Label(screen, text='Room', background='white')
    label_9.grid(row=6, column=0, padx=20, pady=20, sticky='w')

    var1 = tk.IntVar()
    rooms = [
        "Select Room",
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8
    ]

    room = ttk.OptionMenu(screen, var1, *rooms)
    room.grid(row=6, column=1, pady=20, sticky='w')

    # Buttons
    save = tk.Button(screen, text='Save', width=10, border=2, background='#f84477', foreground='white',
                     command=insert_data)
    save.grid(row=7, column=1, padx=15, pady=10)


    # frame=tk.Frame(screen,width=50,height=40,borderwidth=5)
    # frame.grid(row=3,column=5,rowspan=4)

    screen.mainloop()


ip_reg()
