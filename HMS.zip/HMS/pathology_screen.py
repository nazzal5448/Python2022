# developer = <------------Nazzal Kausar-------------->
import pathology_modules as pm
import tkinter as tk
from tkinter import ttk

screen1 = tk.Toplevel()

# title&icon
screen1.title('Pathology')
image = tk.PhotoImage(file='img/laboratory.png')
screen1.iconphoto(True, image)
screen1.iconname('pathology')
screen1.configure(background='white')

# screen centering
screen1_width = screen1.winfo_screenwidth()
screen1_height = screen1.winfo_screenheight()
w_width = 900
w_height = 600
center_x = int(screen1_width / 2 - w_width / 2)
center_y = int(screen1_height / 2 - w_height / 2)
screen1.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')
screen1.resizable(False, False)

image1 = tk.PhotoImage(file='img/laboratory.png')
label = ttk.Label(screen1, image=image1, background='white')
label.grid(row=1, column=0, rowspan=4, padx=40, pady=10)
label1 = ttk.Label(screen1, text='Welcome To Pathology Section'
                   , background='white', foreground='#f84477', font=('Cooper Black', 20))
label1.grid(row=0, column=2, columnspan=3, pady=10, sticky='w')

# Buttons
button_1 = tk.Button(screen1, text='Add Record', width='20', borderwidth='2', bg='#f84477', fg='white',
                     font=('Times', 11, 'bold'), command=pm.add_record, cursor='hand2')
button_1.grid(row=1, column=3, padx=20, sticky='e')

button_2 = tk.Button(screen1, text='Recent Test', borderwidth='2', width='20', bg='#f84477', fg='white',
                     font=('Times', 11, 'bold'), command=pm.recent_tests, cursor='hand2')
button_2.grid(row=2, column=3, padx=20, sticky='e')

button_3 = tk.Button(screen1, text='Search Record', borderwidth='2', width='20', bg='#f84477', fg='white',
                     font=('Times', 11, 'bold'), command=pm.search_record, cursor='hand2')
button_3.grid(row=3, column=3, padx=20, sticky='e')

button_4 = tk.Button(screen1, text='Remove Record', borderwidth='2', width='20', bg='#f84477', fg='white',
                     font=('Times', 11, 'bold'), command=pm.remove_record, cursor='hand2')
button_4.grid(row=4, column=3, padx=20, sticky='e')

def profile():
    import view_profile

button_5 = tk.Button(screen1, text='View Your Profile', borderwidth='2', width='20', bg='#f84477', fg='white',
                     font=('Times', 11, 'bold'), command=profile, cursor='hand2')
button_5.grid(row=5, column=3, padx=20,pady=20, sticky='e')



# Empty label
label2 = tk.Label(screen1, text='         ', background='white')
label2.grid(row=1, column=2, rowspan=4, ipadx=0)

screen1.mainloop()
