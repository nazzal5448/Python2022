# developer="Nazzal Kausar"

import tkinter as tk
from tkinter import ttk

screen = tk.Tk()
screen.title('Admin')
logo = tk.PhotoImage(file='img/logo.png')
screen.iconphoto(False, logo)
screen.configure(border=5, bg='white')

# screen1 centering
screen_width = screen.winfo_screenwidth()
screen_height = screen.winfo_screenheight()

w_width = 900
w_height = 600

center_x = int(screen_width / 2 - w_width / 2)
center_y = int(screen_height / 2 - w_height / 2)

screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

image = tk.PhotoImage(file='img/hospital.png')
label = tk.Label(screen, image=image, background='white')
label.grid(row=0, column=0, sticky='w', rowspan=6)
label_1 = tk.Label(screen, text='         ', bg='white')
label_1.grid(row=0, column=1, rowspan=5, padx=50)

# Buttons
def employee():
    import employee_screen
button_1 = tk.Button(screen, text='Employees', width='20', borderwidth='2', bg='#f84477', fg='white', command=employee)
button_1.grid(row=0, column=2, padx=20, sticky='e')

def p_data():
    # Whole created Abdul Muhaimin

    # Developed and designed By Abdul Muhaimin

    import tkinter as tk
    import uuid
    from tkinter import ttk

    screen1 = tk.Toplevel()
    screen1.title('Patients')
    global logo
    logo = tk.PhotoImage(file="img/medical-file.png")
    screen1.iconphoto(False, logo)
    screen1.configure(bg='white')

    # screen1 centering
    screen1.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

    # screen1 centering

    # code starts here

    Frame1 = tk.Frame(screen1, width=450, height=600, background='white')
    Frame1.pack(side=tk.LEFT, padx=55)

    image = tk.PhotoImage(file='img/account.png')
    screen.iconphoto(False, image)

    label_i = tk.Label(Frame1, image=image, background='white', )
    label_i.pack()

    from db_conn import db
    cursor = db.cursor()
    cursor.execute('select * from treated_patients')
    records = cursor.fetchall()

    frame2 = tk.Frame(screen1)
    frame2.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
    frame2.configure(bg="white")

    my_tree = ttk.Treeview(frame2, columns=(1, 2, 3, 4), show='headings', selectmode='browse')
    my_tree.pack(side='left')

    my_tree.column(1, width=120, anchor='center')
    my_tree.column(2, width=120, anchor='center')
    my_tree.column(3, width=120, anchor='center')
    my_tree.column(4, width=120, anchor='center')

    # mycursor = db.cursor()
    # mycursor.execute('create table treated_patients (id varchar (200), name varchar (200), cause varchar (200), prescription varchar (200) )')

    my_tree.heading(1, text='Id')
    my_tree.heading(2, text='Name')
    my_tree.heading(3, text='Cause')
    my_tree.heading(4, text='Prescription')

    for record in records:
        my_tree.insert((''), 'end', iid=record[0],
                       values=(record[0], record[1], record[2], record[3]))

    style = ttk.Style()
    style.theme_use("clam")

    style.configure("Treeview",
                    background="white",
                    foreground="black",
                    rowheight=55,
                    fieldbackground="white",
                    color='white', )

    verscrlbar = ttk.Scrollbar(frame2,
                               orient="vertical",
                               command=my_tree.yview)
    my_tree.configure(yscrollcommand=verscrlbar.set)

    verscrlbar.pack(side=tk.LEFT, fill='y', expand=True)

    screen.mainloop()


button_2 = tk.Button(screen, text='Patient Data', borderwidth='2', width='20', bg='#f84477', fg='white', command=p_data)
button_2.grid(row=1, column=2, padx=20, sticky='e')

def b_data():
    # Whole created Abdul Muhaimin

    # Developed and designed By Abdul Muhaimin

    import tkinter as tk
    import uuid
    from tkinter import ttk

    screen1 = tk.Toplevel()
    screen1.title('Billing')
    global logo
    logo = tk.PhotoImage(file="img/medical-file.png")
    screen1.iconphoto(False, logo)
    screen1.configure(bg='white')

    # screen1 centering
    screen1.geometry(f'1050x{w_height}+{center_x}+{center_y}')

    # screen1 centering

    # code starts here

    Frame1 = tk.Frame(screen1, width=450, height=600, background='white')
    Frame1.pack(side=tk.LEFT, padx=55)

    image = tk.PhotoImage(file='img/account.png')
    screen.iconphoto(False, image)

    label_i = tk.Label(Frame1, image=image, background='white', )
    label_i.pack()

    from db_conn import db
    cursor = db.cursor()
    cursor.execute('select * from o_bills')
    records = cursor.fetchall()

    frame2 = tk.Frame(screen1)
    frame2.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
    frame2.configure(bg="white")

    my_tree = ttk.Treeview(frame2, columns=(1, 2, 3, 4, 5, 6), show='headings', selectmode='browse')
    my_tree.pack(side='left')

    my_tree.column(1, width=120, anchor='center')
    my_tree.column(2, width=120, anchor='center')
    my_tree.column(3, width=120, anchor='center')
    my_tree.column(4, width=120, anchor='center')
    my_tree.column(5, width=120, anchor='center')
    my_tree.column(6, width=120, anchor='center')

    my_tree.heading(1, text='Fees')
    my_tree.heading(2, text='Test')
    my_tree.heading(3, text='Medicines')
    my_tree.heading(4, text='Salary')
    my_tree.heading(5, text='Expenses')
    my_tree.heading(6, text='date')

    for record in records:
        my_tree.insert((''), 'end', iid=record[0],
                       values=(record[0], record[1], record[2], record[3],record[4], record[5]))

    style = ttk.Style()
    style.theme_use("clam")

    style.configure("Treeview",
                    background="white",
                    foreground="black",
                    rowheight=55,
                    fieldbackground="white",
                    color='white', )

    verscrlbar = ttk.Scrollbar(frame2,
                               orient="vertical",
                               command=my_tree.yview)
    my_tree.configure(yscrollcommand=verscrlbar.set)

    verscrlbar.pack(side=tk.LEFT, fill='y', expand=True)

    screen.mainloop()


button_4 = tk.Button(screen, text='Billing Data', borderwidth='2', width='20', bg='#f84477', fg='white', command=b_data)
button_4.grid(row=2, column=2, padx=20, sticky='e')

def c_pass():
    import change_pass

button_5 = tk.Button(screen, text='change password', borderwidth='2', width='20', bg='#f84477', fg='white', command=c_pass)
button_5.grid(row=3, column=2, padx=20, sticky='e')

def logout():
    screen.destroy()
    import Login

button_5 = tk.Button(screen, text='Logout', borderwidth='2', width='20', bg='#f84477', fg='white', command=logout)
button_5.grid(row=4, column=2, padx=20, sticky='e')


screen.mainloop()
