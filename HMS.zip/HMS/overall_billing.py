# Made By Abdul Muhaimin
from db_conn import db

cursor = db.cursor()

import tkinter as tk
from tkinter import ttk
import uuid
from datetime import date
from tkinter.filedialog import *

screen = tk.Toplevel()
screen.configure(background='white')
screen.title('Accountant / OverAll_Billing')



global image
image = tk.PhotoImage(file='img/account.png')
screen.iconphoto(False, image)

label_i = tk.Label(screen, image=image, background='white', )
label_i.grid(row=0, column=5, columnspan=2, rowspan=8, padx=10, pady=40)

# Menu developed by abdul Muhaimin

menubar = tk.Menu(screen)
# Adding File Menu and commands
file = tk.Menu(menubar, tearoff=0)
menubar.add_cascade(label='File', menu=file)

def logout():
    screen.destroy()

    import Login

file.add_command(label='Logout', command=logout)
file.add_separator()
file.add_command(label='Exit', command=screen.destroy)

# Adding Help Menu
patients_ = tk.Menu(menubar, tearoff=0)
menubar.add_cascade(label='Billing', menu=patients_)
def pb():
    import Patient_billing
patients_.add_command(label='Patient Billing', command=pb)


patients_.add_command(label='Overall Billing')
patients_.add_separator()

screen.config(menu=menubar)
# Menu developed by abdul Muhaimin

screen_width = screen.winfo_screenwidth()
screen_height = screen.winfo_screenheight()
w_width = 900
w_height = 600
center_x = int(screen_width / 2 - w_width / 2)
center_y = int(screen_height / 2 - w_height / 2)
screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

label0 = ttk.Label(screen, text='  ', background='white', foreground='#f84477', font=('Cooper Black', 20))
label0.grid(row=0, column=4, columnspan=2, padx=20, sticky='s')

# Id label And Entry

label1 = tk.Label(screen, text='Fess (Last 30):', background='white', font=('Times', 12, 'bold'))
label1.grid(row=1, column=0, padx=30, pady=20, sticky='w')

cursor.execute("SELECT doctor_fess FROM bills LIMIT 30")

d_fees = []
myresult = cursor.fetchall()
for x in myresult:
    print(x)
    a = sum(x)
    d_fees.append(a)
fees = sum(d_fees)

entry1 = ttk.Entry(screen, background='white')
entry1.grid(row=1, column=1, padx=30, pady=20, ipadx=15, sticky='w')
entry1.insert(0, fees)


# Name label and entry

label2 = tk.Label(screen, text='test (Last 30)', background='white', font=('Times', 12, 'bold'))
label2.grid(row=2, column=0, padx=30, pady=20, sticky='w')

cursor.execute("SELECT test_fess FROM bills LIMIT 30")

t_fees = []
myresult1 = cursor.fetchall()
for x in myresult1:
    print(x)
    a = sum(x)
    t_fees.append(a)
tfees = sum(t_fees)

entry2 = ttk.Entry(screen, background='white', font=('Times', 10))
entry2.grid(row=2, column=1, padx=30, pady=20, ipadx=15, sticky='w')
entry2.insert(0, tfees)



# Age label and entry
label3 = tk.Label(screen, text='Medicines (Last 30)', background='white', font=('Times', 12, 'bold'))
label3.grid(row=3, column=0, padx=30, pady=20, sticky='w')

cursor.execute("SELECT medicines_fess FROM bills  LIMIT 30")
m_fees = []
myresult2 = cursor.fetchall()
for x in myresult2:
    print(x)
    a = sum(x)
    m_fees.append(a)
mfees = sum(m_fees)

entry3 = ttk.Entry(screen, background='white', font=('Times', 10))
entry3.grid(row=3, column=1, padx=30, pady=20, ipadx=15, sticky='w')

entry3.insert(0, mfees)


# Test Type label and entry
label4 = tk.Label(screen, text='Employee Salary (Overall)', background='white', font=('Times', 12, 'bold'))
label4.grid(row=4, column=0, padx=30, pady=20, sticky='w')

cursor.execute("SELECT salary FROM employee")
salary = []
myresult3 = cursor.fetchall()
for x in myresult3:
    print(x)
    a = sum(x)
    salary.append(a)
O_salary = sum(salary)

entry4 = ttk.Entry(screen, background='white', font=('Times', 10))
entry4.grid(row=4, column=1, padx=30, pady=20, ipadx=15, sticky='w')
entry4.insert(0, O_salary)


# Result label and entry
label5 = tk.Label(screen, text='Other Expenses', background='white', font=('Times', 12, 'bold'))
label5.grid(row=5, column=0, padx=30, pady=20, sticky='w')

entry5 = ttk.Entry(screen, background='white', font=('Times', 10))
entry5.grid(row=5, column=1, padx=30, pady=20, ipadx=15, sticky='w')

# Date label and entry
label6 = tk.Label(screen, text='Date', background='white', font=('Times', 12, 'bold'))
label6.grid(row=6, column=0, padx=30, pady=20, sticky='w')

entry6 = ttk.Entry(screen, background='white', font=('Times', 10))
entry6.grid(row=6, column=1, padx=30, pady=20, ipadx=15, sticky='w')
entry6.insert(0, str(date.today()))
entry6.configure(state='disabled')

def save():
    import tkinter as tk
    from tkinter import ttk
    import mysql.connector
    from db_conn import db
    cursor = db.cursor()

    import tkinter as tk
    from tkinter import ttk
    import uuid
    from datetime import date
    screen = tk.Toplevel()
    screen.configure(background='white')
    screen.title('Over All Billing')
    image = tk.PhotoImage(file='img/report.png')
    screen.iconphoto(True, image)
    screen.iconname('pathology')
    screen.configure(background='white')
    image1 = tk.PhotoImage(file='img/account.png')

    image = tk.PhotoImage(file='img/account.png')
    screen.iconphoto(False, image)

    label_i = tk.Label(screen, image=image, background='white', )
    label_i.grid(row=0, column=5, columnspan=2, rowspan=8, padx=10, pady=40)
    fees = entry1.get()
    test = entry2.get()
    medicines = entry3.get()
    salary = entry4.get()
    expenses = entry5.get()
    date = str(date.today())

    # mycursor = db.cursor()
    # mycursor.execute('create table o_bills (fees int, test int, medicines int, salary int, expenses int, date varchar(250)')

    mycursor = db.cursor()

    sql = "INSERT INTO o_bills (fees, test, medicines, salary, expenses, date) VALUES (%s, %s, %s, %s, %s, %s)"
    val = (fees, test, medicines, salary, expenses, date)
    mycursor.execute(sql, val)

    db.commit()

    print(mycursor.rowcount, "record inserted.")

    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()
    w_width = 900
    w_height = 600
    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)
    screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

    label2 = tk.Label(screen, text='Fees: ' + fees + '\n', background='white', font=('Times', 13, 'bold'))
    label2.grid(row=1, column=0, padx=30, pady=20, sticky='w')

    label3 = tk.Label(screen, text='Test Fees: ' + str(test) + '\n', background='white', font=('Times', 13, 'bold'))
    label3.grid(row=2, column=0, padx=30, pady=20, sticky='w')

    label4 = tk.Label(screen, text='Medicines: ' + medicines + '\n', background='white',
                      font=('Times', 13, 'bold'))
    label4.grid(row=3, column=0, padx=30, pady=20, sticky='w')

    label5 = tk.Label(screen, text='Salary: ' + salary + '\n', background='white', font=('Times', 13, 'bold'))
    label5.grid(row=4, column=0, padx=30, pady=20, sticky='w')

    label6 = tk.Label(screen, text='Expenses: ' + expenses + '\n', background='white', font=('Times', 13, 'bold'))
    label6.grid(row=5, column=0, padx=30, pady=20, sticky='w')

    label7 = tk.Label(screen, text='Date: ' + date + '\n', background='white', font=('Times', 13, 'bold'))
    label7.grid(row=6, column=0, padx=30, pady=20, sticky='w')

    screen.mainloop()

# Buttons
button1 = tk.Button(screen, text='save', width=10, background='#f84477', foreground='white',
                    font=('Times', 11, 'bold'), command=save)
button1.grid(row=8, column=1, padx=20, pady=10)

screen.mainloop()
