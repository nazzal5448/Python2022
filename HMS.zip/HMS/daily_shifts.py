# Designed and developes by Abdul muhaimin
from PIL import ImageTk, Image
import tkinter as tk
from tkinter import ttk
screen = tk.Toplevel()
screen.title('Receiptionist / Daily Shifts')
global logo
logo = ImageTk.PhotoImage(Image.open("img/logo.png"))
screen.iconphoto(False, logo)
screen.configure(bg='white')

# Menu developed by abdul Muhaimin

menubar = tk.Menu(screen)
# Adding File Menu and commands
file = tk.Menu(menubar, tearoff=0)
menubar.add_cascade(label='File', menu=file)

def logout():
    screen.destroy()
    import Login

file.add_command(label='Logout', command=logout)
file.add_separator()
file.add_command(label='Exit', command=screen.destroy)

# Adding Help Menu
patients_ = tk.Menu(menubar, tearoff=0)

menubar.add_cascade(label='patients', menu=patients_)
def ip():
    import inpatient_reg

patients_.add_command(label='In-Patient', command=ip)

def op():
    import outdoor_patient

patients_.add_command(label='Outdoor-patients', command=op)
patients_.add_separator()

def emr():
    import Emergency_reg


patients_.add_command(label='Emergency Patients', command=emr)

Others_ = tk.Menu(menubar, tearoff=0)
menubar.add_cascade(label='Others', menu=Others_)
Others_.add_command(label='Daily Shifts')

def dis():
    import discharging

Others_.add_command(label='Discharge Patients', command=dis)

screen.config(menu=menubar)
# Menu developed by abdul Muhaimin

# screen1 centering
screen_width = screen.winfo_screenwidth()
screen_height = screen.winfo_screenheight()

w_width = 900
w_height = 600

center_x = int(screen_width / 2 - w_width / 2)
center_y = int(screen_height / 2 - w_height / 2)

screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

# screen1 centering


screen_label = ttk.Label(screen, text='Welcome TO Daily Shifts', font=('Cooper Black', 22),
                         foreground='#f84477',
                         background='white')
screen_label.pack()

# coding start here

frame1 = tk.Frame(screen)
frame1.pack(side=tk.LEFT)
frame1.configure(bg="white")

label0 = ttk.Label(frame1, text='Assign Duties', background='white', foreground='#f84477',
                       font=('Cooper Black', 20))
label0.grid(row=0, column=0, columnspan=2, padx=20, sticky='s')

# Id label And Entry

label1 = tk.Label(frame1, text='Name', background='white', font=('Times', 12, 'bold'))
label1.grid(row=1, column=0, padx=20, pady=20, sticky='w')

entry1 = ttk.Entry(frame1, background='white')
entry1.grid(row=1, column=1, padx=20, pady=20, ipadx=15, sticky='w')

# Name label and entry

label2 = tk.Label(frame1, text='Department', background='white', font=('Times', 12, 'bold'))
label2.grid(row=2, column=0, padx=20, pady=20, sticky='w')

entry2 = ttk.Entry(frame1, background='white', font=('Times', 10))
entry2.grid(row=2, column=1, padx=20, pady=20, ipadx=15, sticky='w')

# Department label and entry
label3 = tk.Label(frame1, text='Duty', background='white', font=('Times', 12, 'bold'))
label3.grid(row=3, column=0, padx=20, pady=20, sticky='w')

entry3 = ttk.Entry(frame1, background='white', font=('Times', 10))
entry3.grid(row=3, column=1, padx=20, pady=20, ipadx=15, sticky='w')

# Qualification label and entry
label4 = tk.Label(frame1, text='Timing', background='white', font=('Times', 12, 'bold'))
label4.grid(row=4, column=0, padx=20, pady=20, sticky='w')

entry4 = ttk.Entry(frame1, background='white', font=('Times', 10))
entry4.grid(row=4, column=1, padx=20, pady=20, ipadx=15, sticky='w')

def save():
    my_tree.insert((''), 'end', iid=entry1.get(),
                   values=(entry1.get(), entry2.get(), entry3.get(), entry4.get()))



# Buttons
button1 = tk.Button(frame1, text='save', width=10, background='#f84477', foreground='white',
                    font=('Times', 11, 'bold'), command=save)
button1.grid(row=5, column=1, padx=20, pady=20)

frame2 = tk.Frame(screen)
frame2.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
frame2.configure(bg="white")

my_tree = ttk.Treeview(frame2, columns=(1, 2, 3, 4), show='headings', selectmode='browse')
my_tree.pack(side='left')

my_tree.column(1, width=120, anchor='center')
my_tree.column(2, width=120, anchor='center')
my_tree.column(3, width=120, anchor='center')
my_tree.column(4, width=120, anchor='center')

my_tree.heading(1, text='Name')
my_tree.heading(2, text='Department')
my_tree.heading(3, text='Duty')
my_tree.heading(4, text='Timing')

verscrlbar = ttk.Scrollbar(frame2,
                           orient="vertical",
                           command=my_tree.yview)
my_tree.configure(yscrollcommand=verscrlbar.set)

verscrlbar.pack(side=tk.LEFT, fill='y', expand=True)

screen.mainloop()