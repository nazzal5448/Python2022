import mysql.connector as sq

db = sq.connect(
    host="sql6.freesqldatabase.com",
    user="sql6501892",
    password="3Wrabaa1VF",
    database="sql6501892")



# mycursor = db.cursor()
# mycursor.execute("CREATE TABLE receiptionist_data (name VARCHAR(255), password VARCHAR(255))")


# mycursor = db.cursor()
#
# sql = "INSERT INTO receiptionist_data (name, password) VALUES (%s, %s)"
# val = ("receiptionist", "receiptionist")
# mycursor.execute(sql, val)
#
# db.commit()
#
# print(mycursor.rowcount, "record inserted.")


# mycursor = db.cursor()
# mycursor.execute("CREATE TABLE pharmacy_data (name VARCHAR(255), password VARCHAR(255))")

# mycursor = db.cursor()
#
# sql = "INSERT INTO pharmacy_data (name, password) VALUES (%s, %s)"
# val = ("pharmacy", "pharmacy")
# mycursor.execute(sql, val)
#
# db.commit()
#
# print(mycursor.rowcount, "record inserted.")


# mycursor = db.cursor()
# mycursor.execute("CREATE TABLE admin_data (name VARCHAR(255), password VARCHAR(255))")

# mycursor = db.cursor()
#
# sql = "INSERT INTO admin_data (name, password) VALUES (%s, %s)"
# val = ("admin", "admin")
# mycursor.execute(sql, val)
#
# db.commit()
#
# print(mycursor.rowcount, "record inserted.")


# mycursor = db.cursor()
# mycursor.execute("CREATE TABLE accountant_data (name VARCHAR(255), password VARCHAR(255))")

# mycursor = db.cursor()
#
# sql = "INSERT INTO accountant_data (name, password) VALUES (%s, %s)"
# val = ("accountant", "accountant")
# mycursor.execute(sql, val)
#
# db.commit()
#
# print(mycursor.rowcount, "record inserted.")
#
#
# mycursor = db.cursor()
# mycursor.execute("CREATE TABLE doctor_data (name VARCHAR(255), password VARCHAR(255))")

# mycursor = db.cursor()
#
# sql = "INSERT INTO doctor_data (name, password) VALUES (%s, %s)"
# val = ("doctor", "doctor")
# mycursor.execute(sql, val)
#
# db.commit()
#
# print(mycursor.rowcount, "record inserted.")


# mycursor = db.cursor()
# mycursor.execute("CREATE TABLE Pathology_data (name VARCHAR(255), password VARCHAR(255))")

# mycursor = db.cursor()
#
# sql = "INSERT INTO Pathology_data (name, password) VALUES (%s, %s)"
# val = ("Pathology", "Pathology")
# mycursor.execute(sql, val)
#
# db.commit()
#
# print(mycursor.rowcount, "record inserted.")

# mycursor = db.cursor()
# mycursor.execute("CREATE TABLE EM_patient (PatientId VARCHAR(255), name VARCHAR(255), Emergency VARCHAR(255), d_assign VARCHAR(255))")
#
#
# mycursor = db.cursor()
# mycursor.execute("CREATE TABLE In_patient (PatientId VARCHAR(255), Name VARCHAR(255), Gender VARCHAR(255), Contact INT, Age INT)")
#
# mycursor = db.cursor()
# mycursor.execute("CREATE TABLE Out_patient (PatientId VARCHAR(255), Name VARCHAR(255), Gender VARCHAR(255), Contact INT, Age INT)")
#
#
# mycursor = db.cursor()
# mycursor.execute('create table record(Sno int key Auto_increment, ID varchar (200),Name varchar (200),Age int, type varchar (200) , date varchar (100),result varchar (200),remarks varchar(250))')
#
# mycursor = db.cursor()
# mycursor.execute('create table employee (Sno int key Auto_increment, ID varchar (200),Name varchar (200),Age int, department varchar (200) , salary int, qualification varchar (200),remarks varchar(250))')
#
#
# mycursor = db.cursor()
# mycursor.execute('create table payroll (Sno int key Auto_increment, uid varchar (200),Name varchar (200),Age int, department varchar (200) , salary int, qualification varchar (200), loans int, other_charges int, tax int, net_pay int  )')
#
# mycursor = db.cursor()
# mycursor.execute('create table admitted (id varchar (200), Name varchar (200), admit_days int)')
#
# mycursor = db.cursor()
# mycursor.execute('create table bills (id varchar (200), Name varchar (200), doctor_fess int, test_fess int, medicines_fess int)')
#
# mycursor = db.cursor()
# mycursor.execute('create table o_bills (fees int, test int, medicines int, salary int, expenses int, date varchar (200) )')
#
# mycursor = db.cursor()
# mycursor.execute('create table treated_patients (id varchar (200), name varchar (200), cause varchar (200), prescription varchar (200) )')
#
# mycursor = db.cursor()
# mycursor.execute('create table drug (Sno int key Auto_increment, Name varchar (200), price int, Quantity varchar (200), type varchar (200) )')
