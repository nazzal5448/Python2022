from tkinter import *
import tkinter as tk

from tkinter import ttk
from PIL import ImageTk, Image
from time import *

# _____Whole Screen was Designed By Abdul Muhaimin

# Create object
splash_root = Tk()
splash_root.overrideredirect(1)

# screen1 centering
screen_width = splash_root.winfo_screenwidth()
screen_height = splash_root.winfo_screenheight()

w_width = 900
w_height = 600

center_x = int(screen_width / 2 - w_width / 2)
center_y = int(screen_height / 2 - w_height / 2)

splash_root.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

# screen1 centering

logo = ImageTk.PhotoImage(Image.open("img/logo.png"))
splash_root.iconphoto(False, logo)

Frame1 = tk.Frame()
Frame1.pack(side=LEFT, fill='y')
Frame1.configure(background="#171717", width=450, padx=55)

img = ImageTk.PhotoImage(Image.open("img/Login_img.png"))
label1 = ttk.Label(Frame1, image=img, background="#171717", width=450)
label1.image = img
label1.pack(side=LEFT, pady=(0, 65))

# Left Frame

# RIGHT frame
Frame2 = tk.Frame()
Frame2.pack(fill='both', expand=True)
Frame2.configure(background='white', width=450)

# Heading
Heading = ttk.Label(Frame2, text='Starting OurCare...', background='white', foreground="#f84477",
                    font=('Cooper Black', 22))
Heading.grid(row=2, column=2, pady=(125, 0), padx=100)

for i in range(50):
    tk.Label(Frame2, bg="#3e403e", width=2, height=1).place(x=(i+22)*5, y=300)

splash_root.update()


for i in range(50):
    for j in range(1):
        tk.Label(Frame2, bg="#3e403e", width=2, height=1).place(x=(i+22)*5, y=300)
        sleep(0.001)
        splash_root.update_idletasks()
        tk.Label(Frame2, bg="#f84477", width=2, height=1).place(x=(i+22)*5, y=300)



def login():
    splash_root.destroy()
    import tkinter as tk

    from tkinter import ttk
    from PIL import ImageTk, Image

    from tkinter import messagebox

    login = tk.Tk()
    login.config(background="white")
    login.resizable(False, False)
    logo = ImageTk.PhotoImage(Image.open("img/logo.png"))
    login.iconphoto(False, logo)
    login.title("Our Care / Login")

    # screen1 centering
    screen_width = login.winfo_screenwidth()
    screen_height = login.winfo_screenheight()

    w_width = 900
    w_height = 600

    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)

    login.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

    # screen1 centering

    # Code starts Here

    # Left Frame
    Frame1 = tk.Frame()
    Frame1.pack(side=LEFT, fill='y')
    Frame1.configure(background="#171717", width=450, padx=55)

    img = ImageTk.PhotoImage(Image.open("img/Login_img.png"))
    label1 = ttk.Label(Frame1, image=img, background="#171717", width=450)
    label1.image = img
    label1.pack(side=LEFT, pady=(0, 65))

    # Left Frame

    # RIGHT frame
    Frame2 = tk.Frame()
    Frame2.pack(fill='both', expand=True)
    Frame2.configure(background='white', width=450)

    # Heading
    Heading = ttk.Label(Frame2, text='SIGN IN', background='white', foreground="#f84477", font=('Cooper Black', 22))
    Heading.pack(pady=(125, 0))

    def log_in():
        messagebox.showinfo("showinfo", "Signing In")
        import db_conn as db
        # Data Transfer code
        # Developed By Abdul Muhaimin
        if clicked.get() == "Admin":
            print("you are admin")

            # Fecthing username from sql
            cursor = db.db.cursor()
            cursor.execute("Select name From admin_data ")
            user_db = cursor.fetchall()
            print("user:", user_db)

            # getting user's provided username
            Username = user.get()

            for i in user_db[0]:

                # Fecthing password from sql
                cursor2 = db.db.cursor()
                cursor2.execute("Select password From admin_data ")
                pass_db = cursor2.fetchall()
                print("pass:", pass_db)

                # getting user's provided password
                pass_word = password.get()

                for j in pass_db[0]:
                    print("db_user:", i)
                    print("user:", Username)

                    print("db_pass:", j)
                    print("pass:", pass_word, "\n", "________________", "\n")

                    if i == Username and j == pass_word:
                        messagebox.showinfo("showinfo", "Logged In")
                        login.destroy()
                        import admin

                    else:
                        messagebox.showwarning("showwarning", "Wrong credentials")

        elif clicked.get() == "Accountant":
            print("you are Accountant")

            # Fecthing username from sql
            cursor = db.db.cursor()
            cursor.execute("Select name From accountant_data ")
            user_db = cursor.fetchall()
            print("user:", user_db)

            # getting user's provided username
            Username = user.get()

            for i in user_db[0]:

                # Fecthing password from sql
                cursor2 = db.db.cursor()
                cursor2.execute("Select password From accountant_data ")
                pass_db = cursor2.fetchall()
                print("pass:", pass_db)

                # getting user's provided password
                pass_word = password.get()

                for j in pass_db[0]:
                    print("db_user:", i)
                    print("user:", Username)

                    print("db_pass:", j)
                    print("pass:", pass_word)

                    if i == Username and j == pass_word:
                        messagebox.showinfo("showinfo", "Logged In")
                        login.destroy()
                        import Accountant

                    else:
                        messagebox.showwarning("showwarning", "Wrong credentials")

        elif clicked.get() == "Doctor":
            print("you are Doctor")
            # Fecthing username from sql
            cursor = db.db.cursor()
            cursor.execute("Select name From doctor_data ")
            user_db = cursor.fetchall()
            print("user:", user_db)

            # getting user's provided username
            Username = user.get()

            for i in user_db[0]:

                # Fecthing password from sql
                cursor2 = db.db.cursor()
                cursor2.execute("Select password From doctor_data ")
                pass_db = cursor2.fetchall()
                print("pass:", pass_db)

                # getting user's provided password
                pass_word = password.get()

                for j in pass_db[0]:
                    print("db_user:", i)
                    print("user:", Username)

                    print("db_pass:", j)
                    print("pass:", pass_word)

                    if i == Username and j == pass_word:
                        messagebox.showinfo("showinfo", "Logged In")
                        login.destroy()

                        import doctor



                    else:
                        messagebox.showwarning("showwarning", "Wrong credentials")


        elif clicked.get() == "Pharmacy":
            print("you are pharmacist")
            # Fecthing username from sql
            cursor = db.db.cursor()
            cursor.execute("Select name From pharmacy_data ")
            user_db = cursor.fetchall()
            print("user:", user_db)

            # getting user's provided username
            Username = user.get()

            for i in user_db[0]:

                # Fecthing password from sql
                cursor2 = db.db.cursor()
                cursor2.execute("Select password From pharmacy_data ")
                pass_db = cursor2.fetchall()
                print("pass:", pass_db)

                # getting user's provided password
                pass_word = password.get()

                for j in pass_db[0]:
                    print("db_user:", i)
                    print("user:", Username)

                    print("db_pass:", j)
                    print("pass:", pass_word)

                    if i == Username and j == pass_word:
                        messagebox.showinfo("showinfo", "Logged In")
                        login.destroy()

                        import pharmacy_screen

                    else:
                        messagebox.showwarning("showwarning", "Wrong credentials")

        elif clicked.get() == "receiptionist":

            print("you are receiptionist")
            # Fecthing username from sql
            cursor = db.db.cursor()
            cursor.execute("Select name From receiptionist_data ")
            user_db = cursor.fetchall()
            print("user:", user_db)

            # getting user's provided username
            Username = user.get()

            for i in user_db[0]:

                # Fetching password from sql
                cursor2 = db.db.cursor()
                cursor2.execute("Select password From receiptionist_data ")
                pass_db = cursor2.fetchall()
                print("pass:", pass_db)

                # getting user's provided password
                pass_word = password.get()

                for j in pass_db[0]:
                    print("db_user:", i)
                    print("user:", Username)

                    print("db_pass:", j)
                    print("pass:", pass_word)

                    if i == Username and j == pass_word:
                        login.destroy()
                        import receptionist as rc

                        messagebox.showinfo("showinfo", "Logged In")

                    else:
                        messagebox.showwarning("showwarning", "Wrong credentials")

        elif clicked.get() == "Pathology":

            print("you are Pathologist")
            # Fecthing username from sql
            cursor = db.db.cursor()
            cursor.execute("Select name From Pathology_data ")
            user_db = cursor.fetchall()
            print("user:", user_db)

            # getting user's provided username
            Username = user.get()

            for i in user_db[0]:

                # Fetching password from sql
                cursor2 = db.db.cursor()
                cursor2.execute("Select password From Pathology_data ")
                pass_db = cursor2.fetchall()
                print("pass:", pass_db)

                # getting user's provided password
                pass_word = password.get()

                for j in pass_db[0]:
                    print("db_user:", i)
                    print("user:", Username)

                    print("db_pass:", j)
                    print("pass:", pass_word)

                    if i == Username and j == pass_word:
                        login.destroy()
                        import pathology_screen

                        messagebox.showinfo("showinfo", "Logged In")

                    else:
                        messagebox.showwarning("showwarning", "Wrong credentials")

        else:
            messagebox.showwarning("showwarning", "Select Role!")

    # Entries

    user = tk.Entry(Frame2, width=25, fg='black', border=0, bg="white")
    user.place(y=175, x=135)
    user.insert(0, 'Username')

    def p_holder1(event):
        user.delete(0, 'end')

    user.bind('<Button-1>', p_holder1)

    # underline
    line = tk.Frame(Frame2, width=250, height=2, bg='black')
    line.place(y=195, x=135)

    password = tk.Entry(Frame2, width=25, fg='black', border=0, bg="white", show="*")
    password.place(y=235, x=135)
    password.insert(0, 'password')

    def p_holder(event):
        password.delete(0, 'end')

    password.bind('<Button-1>', p_holder)

    # underline
    line1 = tk.Frame(Frame2, width=250, height=2, bg='black')
    line1.place(y=255, x=135)

    # Dropdown menu options
    options = [
        "Select Role",
        "Admin",
        "Accountant",
        "Doctor",
        "Pathology",
        "receiptionist",
        "Pharmacy",

    ]

    # datatype of menu text
    clicked = tk.StringVar()

    # initial menu text

    # Create Dropdown menu
    drop = ttk.OptionMenu(Frame2, clicked, *options)
    drop.pack(pady=(105, 0), padx=(50, 0))
    drop_img = ImageTk.PhotoImage(Image.open("img/drop_png.png"))
    log_sumit = ImageTk.PhotoImage(Image.open("img/log_submit.png"))
    btn = tk.Button(Frame2, text='Submit', bg='white', border=0, borderwidth=0)
    btn.pack(pady=5, padx=(50, 0))

    btn.config(image=log_sumit, command=log_in)

    # RIGHT frame

    login.mainloop()


# Set Interval
splash_root.after(1000, login)

# Execute tkinter
mainloop()
