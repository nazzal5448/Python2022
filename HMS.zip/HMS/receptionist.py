# Developed and designed By Abdul Muhaimin
from PIL import ImageTk, Image

import tkinter as tk
from tkinter import ttk


screen = tk.Toplevel()
screen.title('Receiptionist')
global logo
logo = ImageTk.PhotoImage(Image.open("img/logo.png"))
screen.iconphoto(False, logo)
screen.configure(bg='white')
# screen1 centering
screen_width = screen.winfo_screenwidth()
screen_height = screen.winfo_screenheight()

w_width = 900
w_height = 600

center_x = int(screen_width / 2 - w_width / 2)
center_y = int(screen_height / 2 - w_height / 2)

screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

# screen1 centering

# code starts here

img = tk.PhotoImage(file='img/rec_img.png')
label1 = ttk.Label(screen, image=img, background="white")
label1.image = img
label1.pack()

screen_label = ttk.Label(screen, text='Hello! Receptionist', font=('Cooper Black', 22),
                         foreground='#f84477',
                         background='white')
screen_label.pack()
label2 = ttk.Label(screen, text="Choose, Where To Go?")
label2.pack()

Buttons = tk.Frame(screen, width=355, height=355, bg="white")
Buttons.pack()

def patient_route():
    route = tk.Toplevel()
    route.overrideredirect()
    route.configure(background="white")

    # screen1 centering
    screen_width = screen.winfo_screenwidth()
    screen_height = screen.winfo_screenheight()

    w_width = 450
    w_height = 350

    center_x = int(screen_width / 2 - w_width / 2)
    center_y = int(screen_height / 2 - w_height / 2)

    route.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

    def Execute_inpatient():
        route.destroy()
        import inpatient_reg as ip

    def Execute_outpatient():
        route.destroy()
        import outdoor_patient

    def Execute_emr():
        route.destroy()
        import Emergency_reg

    btn_go1 = tk.Button(route, text="In-Patient Entry", width=20, font=("Arial Black", 12), background="#f84477",
                        foreground="white", cursor="hand2", command=Execute_inpatient)
    btn_go1.pack(padx=55, pady=(55, 15))

    btn_go2 = tk.Button(route, text="Out-Patient Entry", width=20, font=("Arial Black", 12), background="#f84477",
                        foreground="white", cursor="hand2", command=Execute_outpatient)
    btn_go2.pack(padx=55, pady=(55, 15))

    btn_go2 = tk.Button(route, text="Emergency Entry", width=20, font=("Arial Black", 12), background="#f84477",
                        foreground="white", cursor="hand2", command=Execute_emr)
    btn_go2.pack(padx=55, pady=(55, 15))

    # screen1 centering

    route.mainloop()

btn1 = tk.Button(Buttons, text="Patients", width=20, font=("Arial Black", 8), background="#f84477",
                 foreground="white",
                 cursor="hand2", command=patient_route)
btn1.pack(padx=55, pady=(35, 15))

def shifts():
    import daily_shifts


btn2 = tk.Button(Buttons, text="Daily Shifts", width=20, font=("Arial Black", 8), background="#f84477",
                 foreground="white", cursor="hand2", command=shifts)
btn2.pack(padx=55, pady=(35, 15))

def dis():
    import discharging

btn2 = tk.Button(Buttons, text="Discharging Patients", width=20, font=("Arial Black", 8), background="#f84477",
                 foreground="white", cursor="hand2", command=dis)
btn2.pack(padx=55, pady=(35, 15))

def profile():
    import view_profile

btn3 = tk.Button(Buttons, text="View Profile", width=20, font=("Arial Black", 8), background="#f84477",
                 foreground="white", cursor="hand2", command=profile)
btn3.pack(padx=55, pady=(35, 15))

screen.mainloop()
