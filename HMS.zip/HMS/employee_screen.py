# Developer= <-------Nazzal Kausar------>
def employee():
    import tkinter as tk
    from tkinter import ttk
    import employee_modules as em
    global screen1
    screen1 = tk.Toplevel()
    screen1.configure(background='white')

    # title&icon
    screen1.title('Employee')
    image = tk.PhotoImage(file='img/employee.png')
    screen1.iconphoto(True, image)
    screen1.iconname('employee')

    # screen centering
    screen1_width = screen1.winfo_screenwidth()
    screen1_height = screen1.winfo_screenheight()
    w_width = 900
    w_height = 600
    center_x = int(screen1_width / 2 - w_width / 2)
    center_y = int(screen1_height / 2 - w_height / 2)
    screen1.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')
    screen1.resizable(False, False)

    image1 = tk.PhotoImage(file='img/employee (1).png')
    label = ttk.Label(screen1, image=image1, background='white')
    label.grid(row=1, column=0, rowspan=4, columnspan=2, pady=10)
    label1 = ttk.Label(screen1, text='Welcome To Employee Management System'
                       , background='white', foreground='#f84477', font=('Cooper Black', 16))
    label1.grid(row=0, column=3, columnspan=3, padx=10, pady=10)
    label2 = tk.Label(screen1, text='               ', background='white')
    label2.grid(row=1, column=3, rowspan=6, padx=10)

    # Buttons
    button1 = tk.Button(screen1, text='Employee Entry', background='#f84477', foreground='white',
                        command=lambda: [screen1.quit, em.employee_entry()], font=('Times', 11, 'bold'))
    button1.grid(row=1, column=4, padx=10, pady=10, ipadx=32)

    button2 = tk.Button(screen1, text='Employee Removal', background='#f84477', foreground='white',
                        font=('Times', 11, 'bold'), command=lambda: [screen1.quit, em.employee_removal()])
    button2.grid(row=2, column=4, padx=10, pady=10, ipadx=21)

    button3 = tk.Button(screen1, text='Search department', background='#f84477', foreground='white',
                        font=('Times', 11, 'bold'), command=lambda: [screen1.quit, em.employee_department()])
    button3.grid(row=3, column=4, padx=10, pady=10, ipadx=24)

    button4 = tk.Button(screen1, text='Generate Payroll', background='#f84477', foreground='white',
                        command=lambda: [screen1.quit, em.generate_payroll()], font=('Times', 11, 'bold'))
    button4.grid(row=4, column=4, padx=10, pady=10, ipadx=30)
    screen1.mainloop()


employee()
