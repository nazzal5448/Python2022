# Designed and developes by Abdul muhaimin
from PIL import ImageTk, Image
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

screen = tk.Toplevel()
screen.title('Receiptionist / Discharging')
global logo
logo = ImageTk.PhotoImage(Image.open("img/logo.png"))
screen.iconphoto(False, logo)
screen.configure(bg='white')

# Menu developed by abdul Muhaimin

menubar = tk.Menu(screen)
# Adding File Menu and commands
file = tk.Menu(menubar, tearoff=0)
menubar.add_cascade(label='File', menu=file)


def logout():
    screen.destroy()
    import Login


file.add_command(label='Logout', command=logout)
file.add_separator()
file.add_command(label='Exit', command=screen.destroy)

# Adding Help Menu
patients_ = tk.Menu(menubar, tearoff=0)

menubar.add_cascade(label='patients', menu=patients_)


def ip():
    import inpatient_reg


patients_.add_command(label='In-Patient', command=ip)


def op():
    import outdoor_patient


patients_.add_command(label='Outdoor-patients', command=op)
patients_.add_separator()


def emr():
    screen.destroy()
    import Emergency_reg


patients_.add_command(label='Emergency Patients', command=emr)

Others_ = tk.Menu(menubar, tearoff=0)
menubar.add_cascade(label='Others', menu=Others_)


def shifts():
    import daily_shifts
Others_.add_command(label='Daily Shifts', command=shifts)

Others_.add_command(label='Discharge Patients')

screen.config(menu=menubar)
# Menu developed by abdul Muhaimin

# screen1 centering
screen_width = screen.winfo_screenwidth()
screen_height = screen.winfo_screenheight()

w_width = 900
w_height = 600

center_x = int(screen_width / 2 - w_width / 2)
center_y = int(screen_height / 2 - w_height / 2)

screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

# screen1 centering

# coding start here

frame1 = tk.Frame(screen)
frame1.pack(side=tk.LEFT)
frame1.configure(bg="white", )

label0 = ttk.Label(frame1, text='Discharge Patients', background='white', foreground='#f84477',
                   font=('Cooper Black', 20))
label0.grid(row=0, column=0, columnspan=2, padx=20, sticky='s')

# Id label And Entry



label1 = tk.Label(frame1, text='Id', background='white', font=('Times', 12, 'bold'))
label1.grid(row=1, column=0, padx=20, pady=15, sticky='w')

entry1 = ttk.Entry(frame1, background='white')
entry1.grid(row=1, column=1, padx=20, pady=15, ipadx=15, sticky='w')


def discharge():
    cursor.execute(f"DELETE FROM admitted where ID = '{entry1.get()}'")
    db.commit()
    entry1.delete(0, 'end')
    messagebox.showinfo("showinfo", "Data Removed")


button1 = tk.Button(frame1, text='Discharge', width=10, background='#f84477', foreground='white',
                    font=('Times', 11, 'bold'), command=discharge)
button1.grid(row=5, column=0, padx=8, pady=(20, 50))

def print_file():
    import tkinter as tk

    from db_conn import db
    cursor = db.cursor()
    from datetime import date
    screen = tk.Toplevel()
    screen.configure(background='white')
    screen.title('Recent Test')
    image = tk.PhotoImage(file='img/report.png')
    screen.iconphoto(True, image)
    screen.iconname('pathology')
    screen.configure(background='white')
    image1 = tk.PhotoImage(file='img/account.png')

    image = tk.PhotoImage(file='img/account.png')
    screen.iconphoto(False, image)

    label_i = tk.Label(screen, image=image, background='white', )
    label_i.grid(row=0, column=5, columnspan=2, rowspan=8, padx=10, pady=40)

    # mycursor.execute('create table bills (id varchar (200), Name varchar (200), doctor_fess int, test_fess int, medicines_fess int)')
    from db_conn import db
    cursor = db.cursor()

    cursor.execute(f'SELECT * FROM bills where id = "{entry1.get()}"')
    records = cursor.fetchall()
    for record in records:
        id = record[0]
        name = record[1]
        d_fees = record[2]
        t_fees = record[3]
        m_fees = record[4]

        screen_width = screen.winfo_screenwidth()
        screen_height = screen.winfo_screenheight()
        w_width = 900
        w_height = 600
        center_x = int(screen_width / 2 - w_width / 2)
        center_y = int(screen_height / 2 - w_height / 2)
        screen.geometry(f'{w_width}x{w_height}+{center_x}+{center_y}')

        label2 = tk.Label(screen, text='id: ' + id + '\n', background='white', font=('Times', 13, 'bold'))
        label2.grid(row=1, column=0, padx=30, pady=20, sticky='w')

        label3 = tk.Label(screen, text='Name: ' + str(name) + '\n', background='white', font=('Times', 13, 'bold'))
        label3.grid(row=2, column=0, padx=30, pady=20, sticky='w')

        label4 = tk.Label(screen, text='doctor fees: ' +  str(d_fees) + '\n', background='white',
                          font=('Times', 13, 'bold'))
        label4.grid(row=3, column=0, padx=30, pady=20, sticky='w')

        label5 = tk.Label(screen, text='Test Fees: ' + str(t_fees) + '\n', background='white', font=('Times', 13, 'bold'))
        label5.grid(row=4, column=0, padx=30, pady=20, sticky='w')

        label6 = tk.Label(screen, text='Medicines fees: ' + str(m_fees) + '\n', background='white', font=('Times', 13, 'bold'))
        label6.grid(row=5, column=0, padx=30, pady=20, sticky='w')

        label8 = tk.Label(screen, text="Press window + shift +  s, to take screen shot and print", background='yellow', font=('Times', 13, 'bold'))
        label8.grid(row=7, column=0, padx=30, pady=20, sticky='w')

        screen.mainloop()

button1 = tk.Button(frame1, text='Print Bill', width=10, background='#f84477', foreground='white',
                    font=('Times', 11, 'bold'), command=print_file)
button1.grid(row=6, column=0, padx=8, pady=(20, 20))


def search():
    query = entry1.get()
    selections = []
    for child in my_tree.get_children():
        if query in my_tree.item(child)['values']:
            selections.append(child)
        my_tree.selection_set(selections)


button2 = tk.Button(frame1, text='Search', width=10, background='#f84477', foreground='white',
                    font=('Times', 11, 'bold'), command=search)
button2.grid(row=5, column=1, padx=8, pady=(20, 50))

from db_conn import db

cursor = db.cursor()
cursor.execute('select * from admitted LIMIT  0,3')
records = cursor.fetchall()

frame2 = tk.Frame(screen)
frame2.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
frame2.configure(bg="white")

my_tree = ttk.Treeview(frame2, columns=(1, 2, 3), show='headings', selectmode='browse')
my_tree.pack(side='left')

my_tree.column(1, width=130, anchor='center')
my_tree.column(2, width=130, anchor='center')
my_tree.column(3, width=130, anchor='center')

my_tree.heading(1, text='Id')
my_tree.heading(2, text='Name')
my_tree.heading(3, text='Admit Days')

style = ttk.Style()
style.theme_use("clam")

style.configure("Treeview",
                background="white",
                foreground="black",
                rowheight=55,
                fieldbackground="white",
                color='white', )

for record in records:
    my_tree.insert((''), 'end', iid=record[0],
                   values=(record[0], record[1], record[2]))

verscrlbar = ttk.Scrollbar(frame2,
                           orient="vertical",
                           command=my_tree.yview)
my_tree.configure(yscrollcommand=verscrlbar.set)

verscrlbar.pack(side=tk.LEFT, fill='y', expand=True)

screen.mainloop()
